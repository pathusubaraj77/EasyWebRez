import { Component,ViewEncapsulation,OnInit } from '@angular/core';
import { Router,ActivatedRoute}   from '@angular/router';
import { ResultService}           from './roomavailablity/services/services.result'
import { DataProperty}            from './shared/model/dataProperty'
//import { RoomDetailsComponent} from './roomavailablity/component/room-details/room-details.component'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent implements OnInit  {
  title = 'app';
  constructor(private router:Router,
              private route : ActivatedRoute,
              private objResultService:ResultService,
              private clsProp :DataProperty)
  {}
  async ngOnInit() : Promise<any>{}
} 
