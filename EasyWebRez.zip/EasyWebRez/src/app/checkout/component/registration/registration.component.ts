import { Component, OnInit,ViewEncapsulation } from '@angular/core';
import {Router, NavigationEnd}  from '@angular/router'
import {ShopingCartService}     from './../../services/shoping-cart.service'
import {CheckOutService}        from './../../services/check-out.service';
import {DataProperty}           from './../../model/dataProperty'
import {CartInputProp}          from './../../model/cartInputProperty'
import {InvoiceInputProp}       from'./../../model/invoiceInputProperty'
import {CCPaymentProperty}      from'./../../model/ccPaymentProperty'
import {GuestProperty}          from './../../model/guestProperty'
import {Registration}           from './../../model/registration'

import {ServicePath,AngularException}  from './../../../shared/model/service-path'
import * as $       from 'jquery';
import { promise }  from 'protractor'; 
import {FormGroup,FormControl,Validator,FormsModule} from '@angular/forms'
import { ToastrService} from 'ngx-toastr';

@Component({
  selector      : 'app-registration',
  templateUrl   : './registration.component.html',
  encapsulation : ViewEncapsulation.Emulated,
  styleUrls     : ['./registration.component.css'],
  providers     : [ShopingCartService,DataProperty,CartInputProp,InvoiceInputProp,CheckOutService,
                  CCPaymentProperty,GuestProperty,Registration]
})
export class RegistrationComponent implements OnInit {
  isButtondisabled=false
  serviceCharge : any=[];
  Crs           : boolean
  roomRegistrationProp : any =[]
  serviceChargeStatus  : boolean =true
  bookingType : string =''
  noOfNights : any
  isRequreValidation: boolean;
  LodgingTax: any=0;
  constructor(private router : Router,
    public servicePath            : ServicePath,
    private objShopingCartService : ShopingCartService,
    private clsProp               : DataProperty,
    private cartInputProp         : CartInputProp,
    private objInvoiceProp        : InvoiceInputProp, 
    private objCheckOutService    : CheckOutService,
    private objCCPaymentProperty  : CCPaymentProperty,
    public objGuestProperty       : GuestProperty,
    public objRegistration        : Registration,
    private toastr                : ToastrService ,
    public AngularException       :AngularException ) 
    {
      this.objRegistration.imagePath=this.servicePath.ImagePath;
      this.Crs=localStorage["Crs"];      
    }

  ngOnInit() 
  { 
    try{
      //localStorage["bookingType"]=JSON.parse(sessionStorage["SettingsProp"]).BookingType;
      this.bookingType=localStorage["bookingType"]=="RoomType"? "Room Type" : "Room Name"
      this.clsProp.PropertyId=localStorage["PropertyId"];
      this.objRegistration.imagePath=this.servicePath.ImagePath;
      this.objRegistration.searchInputProp=JSON.parse(sessionStorage["InputProp"]);
      this.objRegistration.setDatebyDateformat();
      this.objRegistration.propertyType=localStorage["PropertyType"];
      this.objRegistration.objShoppingcartList=[]
      this.objRegistration.cartListId=0
      this.noOfNights=JSON.parse(sessionStorage["InputProp"]).NofNights
      if(sessionStorage["ConfirmNo"]!=0)
      {
          sessionStorage["ConfirmNo"]=0;
          this.router.navigate(['/crsresult']);
      }
  
      sessionStorage["ConfirmNo"]=0;
      this.getAvailableCartList();
      this.getInvoiceDetails(); 
      this.getSelectedRooms();
      this.getpaymentDetails();
      this.getPolicyDetails();
      this.getselectedCartList('Init');
      this.router.events.subscribe((evt) => {
        if (!(evt instanceof NavigationEnd)) {
            return;
        }
        window.scrollTo(0, 0)
      });
    }
    catch{}    
  }
  
  getAvailableCartList()
  {
    this.cartInputProp.set(sessionStorage["cartListId"],"AccountName",null)

    let body =JSON.stringify({"clsProp" :this.clsProp,"inputProp" :this.cartInputProp});

    this.objShopingCartService.getAvailableCartList(body)
                              .subscribe((response)=>{
                               this.objRegistration.objShoppingcartList=response;                               
                               },(error)=>{ 
                               this.writeException(error,this.clsProp);
                               })
  }

  incrementitemCount($event:any)
  {
    let items=($event);      
    this.objRegistration.id=items.AccountCode;
    let noOfItems=items.NoofItems

    this.objRegistration.count =parseInt($('#'+this.objRegistration.id).val()) +1;
    if(this.objRegistration.count>noOfItems)
    {
      alert("No more items available")
    }
    else
    {
      $('#'+this.objRegistration.id).val(this.objRegistration.count);
    }
  }
  decrementItemCount($event:any)
  {
    this.objRegistration.id=($event)
    this.objRegistration.count =parseInt($('#'+this.objRegistration.id).val())-1;
    if(this.objRegistration.count<0)
    {
      alert("Sorry Please Select Quantity")
    }
    else
    {
      $('#'+this.objRegistration.id).val(this.objRegistration.count);
    }
  }

  getInvoiceDetails()
  {
    this.objInvoiceProp.set(this.objRegistration.searchInputProp.InDate,this.objRegistration.searchInputProp.OutDate,
    0,1,sessionStorage.getItem("RoomListId"),sessionStorage["cartListId"],false,0,"Roomtype",JSON.parse(sessionStorage["InputProp"]).NofNights)
   
    let body =JSON.stringify({"dataProp" :this.clsProp,"inputProp" :this.objInvoiceProp});

    this.objShopingCartService.getInvoiceDetails(body)
                               .subscribe((response)=>{this.objRegistration.objInvoice=response;
                                this.LodgingTax=0;
                                response.LodgingTaxInfo.forEach((obj)=>{this.LodgingTax=this.LodgingTax+obj.TaxTotal});
                                this.serviceCharge=this.objRegistration.objInvoice.HouseKeepingInfo[0]; 
                                if(this.serviceCharge==undefined) this.serviceChargeStatus=false;                             
                                sessionStorage["InvoiceDetails"]=JSON.stringify(this.objRegistration.objInvoice);
                                },(error)=>{ 
                                this.writeException(error,this.clsProp);
                                })
  } 

  getSelectedRooms()
  {
    this.objCheckOutService.getRoomList(this.clsProp)
                          .subscribe((response)=>{
                            this.objRegistration.slectedRooms=response
                            if(this.objRegistration.slectedRooms.length==0)
                            {
                              this.router.navigate(['/roomdetails',localStorage["PropertyId"]])
                            }
                            },(error)=>{ 
                              this.writeException(error,this.clsProp);
                            })

  }

  getguestLogin()
  {
    this.objCheckOutService.getguestLogin(this.clsProp,this.objRegistration.existingEmail)
                           .subscribe((response)=>{this.objGuestProperty=response;
                            if(response.GuestId==0){
                              alert("No Records found");
                            } 
                            else{
                              this.objGuestProperty.IsExGuest=true;
                            }
                            },(error)=>{ 
                              this.writeException(error,this.clsProp);
                            })
  }

  resetGuestDetails()
  {
    this.objGuestProperty=new GuestProperty();
    this.objRegistration.existingEmail=""
  }
  
  getpaymentDetails()
  {
    this.objCheckOutService.getpaymentDetails(this.clsProp)
                           .subscribe((response)=>{
                             this.objRegistration.paymentDetails=response;
                            //  if(this.objRegistration.paymentDetails.paymentType=='NotRqValidation')
                            //  {
                            //   this.isRequreValidation=false
                            //  }
                             this.isRequreValidation=this.objRegistration.paymentDetails.PaymentType=='NotRqValidation'? false : true
                            },(error)=>{ 
                            this.writeException(error,this.clsProp);
                            })
  }

  getPolicyDetails()
  {
    let IsShoppingPolicy=false;
    this.objCheckOutService.getPolicyDetails(this.clsProp,IsShoppingPolicy)
                           .subscribe((response)=>{this.objRegistration.objPolicyDetails=response;                          
                            },(error)=>{ 
                              this.writeException(error,this.clsProp);
                            })
  }

  showPolicy($event : boolean)
  {
    if($event)
    {
      this.objRegistration.isPolicy=true;
    }
    else
    {
      this.objRegistration.isPolicy=false;
    }
  }

  addCartDetails($event :any)
  {
    let cartProp=($event);
    let noOfItems=$('#'+$event.AccountCode).val();
    if(noOfItems==0) 
    {
      alert("Please Select Quantity");
      return false;
    }
    cartProp.NoofItems=noOfItems;
    
    let body =JSON.stringify({"clsProp" :this.clsProp,
    "CartId" : sessionStorage["cartListId"],
    "cartInput" :cartProp});
    
    this.objShopingCartService.addCartDetails(body)
                              .subscribe((response)=>{
                               this.objRegistration.cartListId=response;
                               sessionStorage.setItem("cartListId",this.objRegistration.cartListId);
                               this.getAvailableCartList();
                               this.getselectedCartList('');
                                },(error)=>{ 
                                  this.writeException(error,JSON.parse(body));
                                })
                           
  }

  getselectedCartList(action : string)
  {
    this.cartInputProp.set(sessionStorage["cartListId"],"AccountName",null)

    let body =JSON.stringify({"clsProp" :this.clsProp,"inputProp" :this.cartInputProp});    

    this.objShopingCartService.getselectedCartList(body)
                           .subscribe((response)=>{this.objRegistration.selectedcartList=response;  
                            if(action!='Init'){
                              this.getInvoiceDetails(); 
                            }                          
                            },(error)=>{ 
                              this.writeException(error,this.clsProp);
                            })
  }

  removeCartList($event: any)
  {
    let cartProp=($event);
    let AccId=cartProp.AccountCode;
    
    let body =this.clsProp
    let sCartId = sessionStorage["cartListId"]
    this.objShopingCartService.removeCartList(body,sCartId,AccId)
                              .subscribe((response)=>{
                                this.objRegistration.cartListId=response;
                                this.getAvailableCartList();
                                this.getselectedCartList('');
                                },(error)=>{ 
                                  this.writeException(error,this.clsProp);
                                })
  }

  completeBooking()
  {
    this.isButtondisabled=true;   
    
    this.objCCPaymentProperty.set(this.objRegistration);
    this.objGuestProperty.HomePhone=this.objGuestProperty.CellPhone;
    this.objGuestProperty.WorkPhone=""
    // this.objGuestProperty.Notes=""
    this.objGuestProperty.TravelAgent=""
    // this.objGuestProperty.RefferalId="" 
    let reservinProp = { "CCName" : this.objRegistration.cardType, 
      "GuestId" :this.objGuestProperty.GuestId,
      "CheckInTime"  : "",
      "CheckOutTime"  : "" 
    } 
    this.roomRegistrationProp=JSON.parse(sessionStorage["InputProp"])
    this.roomRegistrationProp.sCartId=this.objRegistration.cartListId;
    this.roomRegistrationProp.RoomListId=sessionStorage["RoomListId"];
    this.objRegistration.objInvoice.TaxTotal=this.objRegistration.objInvoice.TaxTotal-this.LodgingTax;    
    let currencySymbol = "$";
    if(this.objRegistration.objInvoice.AutoHouskeepTotal!=0)
    {
      this.objRegistration.objInvoice.ReservationTotal=this.objRegistration.objInvoice.ReservationTotal-this.objRegistration.objInvoice.AutoHouskeepTotal;
    }
    let body=JSON.stringify({
      "clsProp" : this.clsProp,
      "ccprop" : this.objCCPaymentProperty,
      "guestProp" : this.objGuestProperty,
      "roomProp" : this.roomRegistrationProp,//JSON.parse(sessionStorage["InputProp"]),
      "invoiceSummary" : this.objRegistration.objInvoice,
      "reservinProc" : reservinProp,
      "currencySymbol" : currencySymbol,
      "pageFrom" : "",
      "tranid_paypal" :"",
      "reload1" :"",
      "CCAvenueAuthCode" : "",
      "OrderId": ""
    })

    this.objCheckOutService.completeBooking(body)
                          .subscribe((response)=>{this.objRegistration.confirmNumber=response
                          let responce=this.objRegistration.confirmNumber.split('^');
                          try{
                            if(responce.length>2) 
                            {
                              sessionStorage["ConfirmNo"]=responce[2].replace(/['"]+/g, '');                          
                            }
                            if(responce[1]=='<response>')
                            {
                              this.router.navigate(["/tnk"])
                            }
                            else if(responce[1].replace(/['"]+/g, '')=='<script>')
                            {
                              this.toastr.warning(responce[0]); 
                              this.isButtondisabled=false;
                            }
                          }
                          catch{  
                            console.log(response)
                             this.toastr.warning('Something went wrong'); }
                          },(error)=>{ 
                            this.writeException(error,JSON.parse(body))
                          })
  }

  writeException(error : any ,data :any)
  {
    this.toastr.info("Status : "+error.status+" "+error.statusText)       
    this.AngularException.set(error,"registration.component.ts"); 
    this.AngularException.data=JSON.stringify(data);
    this.objShopingCartService.LogErrorAngToText(this.AngularException);
  }
}

