import {Injectable} from '@angular/core';
import {Request,Response,RequestOptions,Headers,Http} from '@angular/http'
import {Observable} from 'rxjs/Observable';
import {ServicePath} from './../../shared/model/service-path'
import {HttpErrorResponse} from '@angular/common/http';

@Injectable()
export class CheckOutService
{
    constructor(
        private http:Http,
        private servicePath : ServicePath){}  


    getInvoiceDetails(objData: any) : Observable<any>
    {
        let header =new Headers({'Content-Type' : 'application/json; charset=utf-8'});
        let options=new RequestOptions({headers :header});

        return this.http.post(this.servicePath.CheckOut+'GetRoomInvoiceSummary',
                         objData,options)
                        .map((response)=><any>response.json())
                        .catch(this.errorHandler);

    }
    
    getguestLogin(objData :any,email :string) : Observable <any>
    {
        let header =new Headers({'Content-Type' : 'application/json; charset=utf-8'});
        let options=new RequestOptions({headers :header});

        return this.http.post(this.servicePath.CheckOut+'GetExistingGuestDetails?email='+email,
                         objData, options)
                        .map((response)=><any>response.json())
                        .catch(this.errorHandler);
    }

    getpaymentDetails(objData :any) : Observable <any>
    {
        let header =new Headers({'Content-Type' : 'application/json; charset=utf-8'});
        let options=new RequestOptions({headers :header});

        return this.http.post(this.servicePath.CheckOut+'GetPaymentSettings',
                         objData, options)
                        .map((response)=><any>response.json())
                        .catch(this.errorHandler);
    }
 
    getPolicyDetails(objData :any,IsShoppingPolicy :boolean) : Observable <any>
    {
        let header =new Headers({'Content-Type' : 'application/json; charset=utf-8'});
        let options=new RequestOptions({headers :header});

        return this.http.post(this.servicePath.CheckOut+'GetPolicyInfo?IsShoppingPolicy='+IsShoppingPolicy,
                         objData, options)
                        .map((response)=><any>response.json())
                        .catch(this.errorHandler);
    }


    completeBooking(data : any) :  Observable <any>
    {
      let headers = new Headers({'Content-Type' : 'application/json; charset=utf-8'});
      let options=new RequestOptions({headers :headers});

      return this.http.post(this.servicePath.CheckOut+'PaymentProcess',
                      data,options).map((response)=><any>response.json())
                      .catch(this.errorHandler);
    }

    getGuestDetails(data : any,confirmNo : string) : Observable <any>
    {
      let headers = new Headers({'Content-Type' : 'application/json; charset=utf-8'});
      let options=new RequestOptions({headers :headers});

      return this.http.post(this.servicePath.ThankYouBooing+'GetGuestDetails?confirmNum='+confirmNo,
                      data,options).map((response)=><any>response.json())
                      .catch(this.errorHandler);
    }

    getDynamicText(data : any) : Observable <any>
    {
      let headers = new Headers({'Content-Type' : 'application/json; charset=utf-8'});
      let options=new RequestOptions({headers :headers});

      return this.http.post(this.servicePath.ThankYouBooing+'GetDynamicText',
                      data,options).map((response)=><any>response.json())
                      .catch(this.errorHandler);
    }

     //get selected rooms list
     getRoomList(data : any) : Observable<any>
     {
       let headers = new Headers({'Content-Type' : 'application/json; charset=utf-8'});
       let options=new RequestOptions({headers :headers});
       
       return this.http.post(this.servicePath.SearchResult+
                       'GetRoomListSummary?roomListId='+sessionStorage["RoomListId"],data,options)
                       .map((response:Response)=><any>response.json())
                       .catch(this.errorHandler);
     }

     errorHandler(error: HttpErrorResponse)  
     {
       return Observable.throw(error || "Server Error")    
     }
     LogErrorAngToText(body:any) : any
     {
       let headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8' });
       let options = new RequestOptions({ headers: headers});
   
       this.http.post(this.servicePath.RoomDetails+'LogErrorAngToText',
                         JSON.stringify(body),options).toPromise();                    
     }
}