import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import {RegistrationComponent} from './component/registration/registration.component'
import {CheckOutService} from './services/check-out.service'
import {ShopingCartService} from './services/shoping-cart.service'
import {SharedModule} from './../shared/shared.module'

@NgModule({
    imports: [ 
        FormsModule,
        BrowserModule,
        SharedModule,
        // RouterModule.forChild([
        //     {path :'reg', component: RegistrationComponent}            
        // ])
        RouterModule.forRoot([ 
            {path :'reg', component: RegistrationComponent}  
          ])
    ],
    declarations :[RegistrationComponent],
    providers:[CheckOutService,ShopingCartService]
})
export  class CheckOutModule{}
