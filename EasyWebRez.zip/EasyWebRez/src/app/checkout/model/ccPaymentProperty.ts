
import {Registration} from './registration'
export class CCPaymentProperty
{
    public  NameOnCard : string 
    public  CVVNo : string 
    public  CCNumber : string 
    public  ExpDate : string
    public  PaymentType : string
    public  IsBillingAddress : boolean
    public  BillingAddress1 : string
    public  BillingAddress2 : string
    public  BillingCity : string
    public  BillingState : string
    public  BillingCountry : string
    public  BillingZipCode : string
    public  IsDisablePayment : boolean
  
    set(objRegistration:Registration)
    {
        this.NameOnCard=objRegistration.Name
        this.CVVNo=objRegistration.cvv
        this.CCNumber=objRegistration.CardNumber
        this.ExpDate=objRegistration.expiryMonth+'/20'+objRegistration.expiryYear;
        this.PaymentType=""
        this.BillingAddress1=""
        this.BillingCity=""
        this.BillingState=""
        this.BillingZipCode=""

        // this.NameOnCard="Pathu"
        // this.CVVNo="411"
        // this.CCNumber="4111111111111111"
    }
}