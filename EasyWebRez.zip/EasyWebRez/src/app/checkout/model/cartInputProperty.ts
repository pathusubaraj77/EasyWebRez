export class CartInputProp
{
    public sCartId : number
    public CartDisplayOrder : string
    public Acccode : any

    set(sCartId : number,CartDisplayOrder : string,Acccode : any)
    {
        this.sCartId=sCartId
        this.CartDisplayOrder=CartDisplayOrder
        this.Acccode=Acccode
    }
}