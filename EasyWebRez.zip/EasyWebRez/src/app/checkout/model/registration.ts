export class Registration
{
  sCartId : number 
  cartDisplayOrder : string
  acccode : any
  objShoppingcartList :any
  objInvoice :any=[];
  id : any;
  count :number = 0
  searchInputProp : any=[]
  slectedRooms : any=[]
  guestDetails : any=[];
  existingEmail :string ="";
  paymentDetails : any=[];
  cardType : string ="0"
  expiryMonth : string ="04"
  expiryYear :string ="20"
  objPolicyDetails :any =[];
  isPolicy : boolean =false;
  cartListId : any =0;
  selectedcartList : any =[];
  cvv : any = '';
  Name : any = '';
  CardNumber :any =''
  confirmNumber : any=""
  imagePath : string=""
  propertyType : string =""
  userAgree : boolean
  strCheckIn : string
  strCheckOut: string

  constructor()
  {
    this.count=0;
    this.objPolicyDetails=[]
    this.cardType="0"
    //this.Name="pathu"
    //this.cvv=411
    //this.CardNumber=4111111111111111;
  } 

  setDatebyDateformat()
  {
    this.strCheckIn=localStorage["checkIn"]
    this.strCheckOut=localStorage["checkOut"]
    if(localStorage["dateFormat"]=='dd/mm/yy')
    {
        let df = localStorage["checkIn"].split('/');
        let dt = localStorage["checkOut"].split('/');
       
        this.searchInputProp.InDate=df[1]+'/'+df[0]+'/'+df[2]
        this.searchInputProp.OutDate=dt[1]+'/'+dt[0]+'/'+dt[2]        
    }
    else
    {
      this.searchInputProp.InDate =localStorage["checkIn"]
      this.searchInputProp.OutDate =localStorage["checkOut"]
    }
  }
}