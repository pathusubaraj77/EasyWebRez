export class ReservationinputProp
{
    public  GuestId : number
    public  ContactId :number
    public  CCName : string
    public  CheckInTime : string
    public  CheckOutTime : string
    public  Response_code : string
    public  Response_msg : string
    public  Trans_ID : string
}