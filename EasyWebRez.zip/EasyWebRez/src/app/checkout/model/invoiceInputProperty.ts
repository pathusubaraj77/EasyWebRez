export class InvoiceInputProp
{
    public InDate : any
    public OutDate :any
    public NofChildren : number
    public NofAdults : number
    public RoomListId : any
    public sCartId : any
    public IsPromoOnline :any
    public PromoCode:any
    public bookingType :any
    public NofNights : number
    public PropertyName :any
    public PropertyType :any
    public SelectedRooms :any

    set(InDate : any,OutDate :any,NofChildren : number,NofAdults : number,RoomListId : any,
        sCartId : any,IsPromoOnline :any,PromoCode:any,bookingType :any,NofNights : number)
    {
        this.InDate=InDate
        this.OutDate=OutDate 
        this.NofChildren=NofChildren
        this.NofAdults=JSON.parse(sessionStorage["InputProp"]).NofAdults
        this.RoomListId=RoomListId
        this.sCartId=sCartId
        this.IsPromoOnline=IsPromoOnline
        this.PromoCode=PromoCode
        this.bookingType=bookingType
        this.NofNights=NofNights
        this.PropertyName=localStorage["PropertyName"]
        this.PropertyType=localStorage["PropertyType"];
    }
}