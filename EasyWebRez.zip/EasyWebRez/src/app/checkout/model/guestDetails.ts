// export class GuestDetails 
// {
//     public Firstname : string
//     public LastName : string
//     public Email : string
//     public Phone : string
//     public Address1 : string
//     public Address2 : string
//     public City : string
//     public State : string
//     public Pincode :string    
// }