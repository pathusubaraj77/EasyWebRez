export class GuestProperty
{
    public  GuestId : number
    public  ContactId :number
    public  IsExGuest :boolean
    public  FirstName : string
    public  LastName : string
    public  Address1 : string
    public  Address2 : string
    public  City : string
    public  State : string
    public  Country : string
    public  Zip : string
    public  Email : string
    public  CellPhone : string
    public  HomePhone : string
    public  WorkPhone : string
    public  Custom1 : string
    public  Custom2 : string
    public  Custom3 : string
    public  Custom4 : string
    public  Custom5 : string
    public  Notes : string
    public  TravelAgent : string
    public  RefferalId : string
    public  BirthDate : string
    public  AnniversaryDate : string
    public  SalesID : string
    public  Propid : number
    public  CName : string

    constructor()
    {
     this.IsExGuest=false
     this.LastName=""
     this.Country=""
     this.HomePhone=""
     this.WorkPhone=""
     this.CellPhone=""
     this.Address1=""
     this.Notes=""
     this.TravelAgent=""
     this.RefferalId=""
     this.City=''
     this.State = ''
     this.Zip =''
    }

    //travel agent
    //isguestexist

}