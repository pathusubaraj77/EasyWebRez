export class DataProperty
{
    public  PropertyId : number
    public  PMSFolder : string="PMS"
}
