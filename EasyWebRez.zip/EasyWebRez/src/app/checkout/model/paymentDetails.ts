export class PaymentDetails
{
    public CardType :string
    public CardNumber :string
    public Cvv :string
    public Name :string
    public ExpiryYear :string
    public ExpiryMonth : number
}