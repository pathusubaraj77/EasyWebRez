import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crs-footer',
  templateUrl: './crs-footer.component.html',
  styleUrls: ['./crs-footer.component.css']
})
export class CrsFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
