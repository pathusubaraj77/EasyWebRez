import { Component,OnChanges, SimpleChanges, Input,OnInit, ElementRef, ViewChild,EventEmitter,Output } from '@angular/core';
import {NgbDateStruct, NgbCalendar, NgbDatepickerConfig,NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import {ResultService} from './../../../roomavailablity/services/services.result'
import {DataProperty} from './../../../shared/model/dataProperty'
import {AngularException}         from './../../model/service-path'
import { addDays } from 'date-fns';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap/datepicker/ngb-date';
import {BlockRoomsRequest} from './../../model/dataProperty'
@Component({
  selector: 'app-datepicker-range',
  templateUrl: './datepicker-range.component.html',
  styleUrls: ['./datepicker-range.component.css'],
  host: {
    "(document:click)": "onClick($event)"
  }
})
export class NgbdDatepickerRange implements OnInit {

  fromDate: NgbDateStruct;  
  toDate: NgbDateStruct;
  inDate:any
  outDate:any
  minDate :any
  customdate: any
  dateFormat: string
  blockdates :any
  isCalendar : boolean;
  blockdateArray: any =[]
  model: NgbDateStruct;
  propertySettings :any
  message: string = ""
  @Input() isRatesChanges : boolean = false
  @Output() messageEvent = new EventEmitter<string>();

  constructor(private calendar         : NgbCalendar,
              private objDateformat    : NgbDateParserFormatter,
              private objResultService : ResultService,
              private clsProp          : DataProperty,
              public AngularException :AngularException,
              private _eref: ElementRef    ,
              public objBlockRoomsRequest : BlockRoomsRequest,
              public config: NgbDatepickerConfig
                  
  ) { this.isCalendar=false;}
  fromDateChange()
  {
    this.inDate=this.objDateformat.format(this.fromDate,this.dateFormat)
    localStorage["checkIn"]=this.inDate  
    this.toDate=this.calendar.getNextdate(this.fromDate,'d',this.propertySettings.DftNoofNights)
    this.outDate=this.objDateformat.format(this.toDate,this.dateFormat)
    localStorage["checkOut"]=this.outDate
    this.toDate=this.objDateformat.parse(localStorage["checkOut"],this.dateFormat) 
    if(this.isRatesChanges){
      this.getRatesChanges()
    }    
  }
  toDateChange()
  {
    this.outDate=this.objDateformat.format(this.toDate,this.dateFormat)
    localStorage["checkOut"]=this.outDate
    this.getRatesChanges()
  }

  ngOnInit()
  {
    this.clsProp.PropertyId=localStorage["PropertyId"]
    this.GetPropertySettings();
  }

  @ViewChild("d") datePicker1;
  @ViewChild("d1") datePicker2;  

  public onClick(event) { // close the datepicker when user clicks outside the element
    if (!this._eref.nativeElement.contains(event.target)) {
      this.datePicker1.close();
      this.datePicker2.close();
    }
  }

  GetPropertySettings()
  {
    this.objResultService.GetPropertySettings(this.clsProp)
    .subscribe((message)=>
    { 
      this.propertySettings=message
      //console.log(message)
      this.getPropertySettingDetails();
    })
  }

  getPropertySettingDetails(){
    this.objResultService.getPropertySettingDetails(this.clsProp)
    .subscribe((message)=>
    { 
      this.propertySettings.DftNoofNights=this.propertySettings.DftNoofNights==0? 2 :this.propertySettings.DftNoofNights;
      sessionStorage["SettingsProp"]=JSON.stringify(message);
      localStorage["dateFormat"]=JSON.parse(sessionStorage["SettingsProp"]).DateFormate;
      localStorage["bookingType"]=JSON.parse(sessionStorage["SettingsProp"]).BookingType;
      this.dateFormat=localStorage["dateFormat"];
      this.fromDate =localStorage["checkIn"]==undefined || localStorage["checkIn"]==""? this.calendar.getNext(this.calendar.getToday(), 'd', 1): this.objDateformat.parse(localStorage["checkIn"],this.dateFormat);
      this.toDate =localStorage["checkOut"]==undefined || localStorage["checkOut"]=="" ? this.calendar.getNext(this.calendar.getToday(), 'd', this.propertySettings.DftNoofNights+1) : this.objDateformat.parse(localStorage["checkOut"],this.dateFormat);
      this.minDate=this.calendar.getToday();
      this.inDate=localStorage["checkIn"]==undefined || localStorage["checkIn"]==""? this.objDateformat.format(this.fromDate,this.dateFormat): localStorage["checkIn"]
      this.outDate=localStorage["checkOut"]==undefined || localStorage["checkOut"]==""? this.objDateformat.format(this.toDate,this.dateFormat):localStorage["checkOut"]
      localStorage["checkIn"]=this.inDate
      localStorage["checkOut"]=this.outDate
    },(error)=>{ 
      this.writeException(error,this.clsProp);
    });
    if(localStorage["directLand"]!=undefined && localStorage["directLand"]!="false"){
      this.GetBlockRoomDetails();
    }
  }

  GetBlockRoomDetails()
  {
    const d1= this.calendar.getToday();
    const d2 = this.calendar.getNext(this.calendar.getToday(), 'y', 2);
    
    let fromBlockdate= d1.month+'/'+d1.day+'/'+d1.year;
    let toBlockdate= d2.month+'/'+d2.day+'/'+d2.year;;

    this.objBlockRoomsRequest.fromDate=fromBlockdate
    this.objBlockRoomsRequest.toDate=toBlockdate
    this.objBlockRoomsRequest.propertyId=this.clsProp.PropertyId;
    this.objBlockRoomsRequest.roomId=localStorage["RoomId"];
    this.objResultService.GetBlockRoomDetails(this.objBlockRoomsRequest)
    .subscribe((message)=>
    { 
      //console.log(message)
      this.blockdates=message.filter(obj=>obj.roomId==localStorage["RoomId"])
      
      this.blockdateArray = this.blockdates.map(value => {
          return  new Date(value.blockDate.split(' ')[0]).getMonth()+1+'/'+
                  new Date(value.blockDate.split(' ')[0]).getDate()+'/'+
                  new Date(value.blockDate.split(' ')[0]).getFullYear()                
  
      });

      this.isCalendar=true;   

    this.config.markDisabled = (date: NgbDateStruct) => {
      const d = new Date(date.year, date.month - 1, date.day);
      let datestring= d.getMonth()+1+'/'+d.getDate()+'/'+d.getFullYear();
      let test=this.blockdateArray.indexOf(datestring)
      return test!=-1 ?true :false;
    };

    this.config.outsideDays = 'hidden';
    
      //console.log( this.blockdates)
      //console.log( this.blockdateArray)
    },(error)=>{ 
      this.writeException(error,this.clsProp);
    });
  }

  writeException(error : any ,data :any)
  {
    //this.toastr.info("Status : "+error.status+" "+error.statusText)       
    this.AngularException.set(error,"app-footer.component.ts"); 
    this.AngularException.data=JSON.stringify(data);
    this.objResultService.LogErrorAngToText(this.AngularException);
  }
  
  getRatesChanges()
  {
    let rateProp= JSON.parse(localStorage["RateChangesObj"]);
    rateProp.ArrDate=localStorage["checkIn"]
    rateProp.DeptDate=localStorage["checkOut"]
    if(localStorage["dateFormat"]=='dd/mm/yy')
    {
        let df = localStorage["checkIn"].split('/');
        let dt = localStorage["checkOut"].split('/');
       
        rateProp.ArrDate=df[1]+'/'+df[0]+'/'+df[2]
        rateProp.DeptDate=dt[1]+'/'+dt[0]+'/'+dt[2]        
    }

    this.objResultService.getRatesChanges(rateProp)
    .subscribe((message)=>
    { 
      this.messageEvent.emit(message)
    },(error)=>{ 
      this.writeException(error,this.clsProp);
    });
  }
}
