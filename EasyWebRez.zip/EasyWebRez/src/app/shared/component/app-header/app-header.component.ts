import { Component, OnInit,ViewEncapsulation,Input,ViewChild, ElementRef, TemplateRef  }  from '@angular/core';
import { DataProperty }      from './../../model/service-path'
import { Header }            from './../../model/header'
import { SharedService}      from './../../services/shared.service'
import {ServicePath,AngularException}         from './../../model/service-path'
import {Router}              from '@angular/router'
import{ResultService}        from '../../../roomavailablity/services/services.result'
import { ToastrService} from 'ngx-toastr';
@Component({
  selector      : 'app-app-header',
  templateUrl   : './app-header.component.html',
  encapsulation : ViewEncapsulation.None,
  styleUrls     : ['./app-header.component.css'] 
})
export class AppHeaderComponent implements OnInit {  
 
  shortName : string =""
  userName : string =""
  password : string =""
  url : any
  headerType ='';
  IsCustomHeader : any
  features :any
  tempHtml :any
  HtmlTemplate =''
  customHeaderPath =''
  HtmlTemplateCssUrl=''
  @Input() headerModule: string =''
  @ViewChild('styleLink') styleLink : ElementRef;

  //Dynamic Templates code declaration
  thenTemplate:TemplateRef<any>|null=null;

  @ViewChild('firstTemplate')
  firstTemplate:TemplateRef<any>|null=null;

  @ViewChild('secondTemplate')
  secondTemplate:TemplateRef<any>|null=null;

  @ViewChild('crsHeaderTemplate')
  crsHeaderTemplate:TemplateRef<any>|null=null;

  @ViewChild('customHeaderTemplate')
  customHeaderTemplate:TemplateRef<any>|null=null;

  @ViewChild('elseTemplate')
  elseTemplate:TemplateRef<any>|null=null;
  IsTemplate :boolean;

  constructor(private clsProp         : DataProperty,
              public  servicePath     : ServicePath,
              private sharedService   : SharedService,
              public AngularException : AngularException,
              public ResultService    : ResultService,
              private toastr    : ToastrService ,
              public objHeader        : Header,
              public router           : Router  , 
              public el: ElementRef                         
              )
              { 
                this.objHeader.ImagePath=this.servicePath.ImagePath;
                this.objHeader.id=localStorage["PropertyId"]
                this.url="https://apps.gracesoft.com/pmsui/verifyhubspotlogin.asp?"
                this.objHeader.isCrsFlow=Boolean(localStorage["crsFlow"]=="true");
                this.customHeaderPath=this.servicePath.customHeaderPath;
                this.HtmlTemplateCssUrl=this.servicePath.customHeaderPath+this.objHeader.id+".css"   
                this.styleLink =this.el;
              }

  ngOnInit() 
  {   
    // this.IsTemplate = true;
    // this.thenTemplate=this.firstTemplate;

    this.clsProp.PropertyId=localStorage["PropertyId"];
    if(localStorage["directLand"]!=undefined && localStorage["directLand"]=="true"){
      this.objHeader.isCrsFlow=false;
    }    
    this.GetPropertySettings();
    this.sharedService.getHeaderDetails(this.clsProp)
                .subscribe((response)=>{    
                this.objHeader.logoImage= response.LogoImage==undefined?"" :  response.LogoImage
                sessionStorage.setItem("Header", JSON.stringify(response))
                },(error)=>{ 
                  this.writeException(error,this.clsProp);
                });
    this.getPropertyDetaills();
  }

  redirect() 
  {
    if(localStorage["directLand"]=="true"){
      this.router.navigate(['/crsroomdetails',{pId :localStorage["PropertyId"],rId:localStorage["RoomId"] }]);
    }
    else
    {
      if(this.objHeader.propDetails.WebSite=="")
      {
        this.router.navigate(['/roomdetails',this.objHeader.id]);
      }
      else{
        this.router.navigate(['/roomdetails',this.objHeader.id]);
        // window.location.href=this.objHeader.propDetails.WebSite        
        // window.open(this.objHeader.propDetails.WebSite )
        //   this.router.navigate(['/externalRedirect', { externalUrl: this.objHeader.propDetails.WebSite  }], {
        //     skipLocationChange: true,
        // });
      }      
    }
  }

  getCustomHeaderHtml(propId : string)
  {
    this.ResultService.getCustomHeaderHtml(propId)
                      .subscribe((message)=>
                      {
                        this.IsTemplate=true
                        this.thenTemplate=this.customHeaderTemplate;
                        this.tempHtml=message;
                        this.HtmlTemplate=this.tempHtml._body;
                        this.HtmlTemplateCssUrl=this.servicePath.customHeaderPath+this.objHeader.id+".css"
                      },(error)=>{ 
                        this.IsTemplate=false;
                        this.headerType='defaultHeader';
                        this.toastr.info("Custom Header Not Found");  
                        this.writeException(error,this.clsProp);
                      }); 
  }

  getPropertyDetaills()
  {
    this.ResultService.getPropertyDetails(this.clsProp)
                      .subscribe((message)=>
                      {
                      this.objHeader.propDetails=message;
                      this.objHeader.phone=this.objHeader.propDetails.Phone; 
                      },(error)=>{ 
                        this.writeException(error,this.clsProp);
                      }); 
  }

  GetPropertySettings()
  {
    this.ResultService.GetPropertySettings(this.clsProp)
    .subscribe((message)=>
    { 
      this.features=message;
      let Links=JSON.stringify({IsAboutUs : this.features.IsAboutUs,
        IsPhotoPage : this.features.IsPhotoPage})
        localStorage["HFLinks"]=Links;
      
      if(this.objHeader.isCrsFlow) //for Crs Layout
      {
        this.headerType='crsHeader'
        this.IsTemplate=true
        this.thenTemplate=this.crsHeaderTemplate;
      }
      else if(this.features.IsCustomHeader) //for custom header Layout
      {
        this.IsCustomHeader=true
        this.headerType=this.headerModule=='crsroomdetails' ? 'defaultHeader' : 'customHeader';
        this.styleLink.nativeElement.setAttribute('href',this.HtmlTemplateCssUrl);
        this.getCustomHeaderHtml(this.objHeader.id);        
      }
      else
      {
        this.IsCustomHeader=false
        //Assigning dynamic template design from setup side
        switch(this.features.LayoutDesign)
        {
          case 1  : //for Layout 1
                  this.IsTemplate=true;
                  this.thenTemplate=this.firstTemplate
                  break;                  
          case 2  : //for Layout 2
                  this.IsTemplate=true;
                  this.thenTemplate=this.secondTemplate
                  break;
          default : //for Default Layout
                  this.IsTemplate=false;
                  this.headerType='defaultHeader'
                  break;
        }
      }
      //console.log(message)
    },(error)=>{ 
      this.writeException(error,this.clsProp);
    })
  }

  submit()
  {
    window.open(this.url+"shortname="+this.shortName+"&userid="+this.userName+"&pwd="+this.password,'MyWindow')
  }

  writeException(error : any ,data :any)
  {
    //this.toastr.info("Status : "+error.status+" "+error.statusText)       
    this.AngularException.set(error,"app-header.component.ts"); 
    this.AngularException.data=JSON.stringify(data);
    this.ResultService.LogErrorAngToText(this.AngularException);
  }
}

