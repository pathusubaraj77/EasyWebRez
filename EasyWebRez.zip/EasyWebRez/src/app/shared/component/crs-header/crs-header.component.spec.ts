import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrsHeaderComponent } from './crs-header.component';

describe('CrsHeaderComponent', () => {
  let component: CrsHeaderComponent;
  let fixture: ComponentFixture<CrsHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrsHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrsHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
