import { Component, OnInit } from '@angular/core';
import {ServicePath} from './../../../shared/model/service-path';
@Component({
  selector: 'app-crs-header',
  templateUrl: './crs-header.component.html',
  styleUrls: ['./crs-header.component.css']
})
export class CrsHeaderComponent implements OnInit {
  shortName : string =""
  userName : string =""
  password : string =""
  url : any
  constructor( 
    public servicePath : ServicePath)
    {
      this.url="https://apps.gracesoft.com/pmsui/verifyhubspotlogin.asp?"
    }

  ngOnInit() {
  }
  submit()
  {
    window.open(this.url+"shortname="+this.shortName+"&userid="+this.userName+"&pwd="+this.password,'MyWindow')
  }
}
