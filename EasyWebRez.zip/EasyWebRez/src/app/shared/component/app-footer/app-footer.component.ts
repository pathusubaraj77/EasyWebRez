import { Component, OnInit,ViewEncapsulation }   from '@angular/core';
import { DataProperty }       from './../../model/service-path'
import { Footer }             from './../../model/footer'
import { SharedService}       from './../../services/shared.service'
import { ServicePath,AngularException } from './../../model/service-path'
import{ResultService}         from '../../../roomavailablity/services/services.result'

@Component({
  selector: 'app-app-footer',
  templateUrl: './app-footer.component.html',
  styleUrls: ['./app-footer.component.css'],
  encapsulation : ViewEncapsulation.Emulated
})
export class AppFooterComponent implements OnInit {

  PropertyType : string =""
  Address : string = ""
  objLinks : any =[]
  constructor(private clsProp : DataProperty,
              public  objFooter  : Footer,
              public AngularException :AngularException,
              private sharedService :SharedService,
              public ResultService:ResultService)  { 
              this.objFooter.isCrsFlow=Boolean(localStorage["crsFlow"]=="true");
              }
  ngOnInit() 
  {
    this.PropertyType=localStorage["PropertyType"]
    this.clsProp.PropertyId=localStorage["PropertyId"];
    if(localStorage["directLand"]!=undefined && localStorage["directLand"]=="true"){
      this.objFooter.isCrsFlow=false;
    }
 
    // {{objFooter.objPropDetails.City}}, 
    //                    {{objFooter.objPropDetails.State}},
    //                    {{objFooter.objPropDetails.Country}} {{objFooter.objPropDetails.Zip}}
    //Getting bottom showing room names
    this.sharedService.getPropertyDetails(this.clsProp)
                         .subscribe((message)=>{
                          this.objFooter.objPropDetails=message;
                          // this.Address=this.addSeperator(this.objFooter.objPropDetails.City)
                          // this.Address=this.Address+this.addSeperator(this.objFooter.objPropDetails.State)
                          // this.Address=this.Address+this.addSeperator(this.objFooter.objPropDetails.Country)
                          // this.Address=this.Address+this.addSeperator(this.objFooter.objPropDetails.Zip)                       
                          // this.objFooter.objPropDetails.Address=
                          // this.objFooter.objPropDetails.Address.length>2? 
                          // this.objFooter.objPropDetails.Address.slice(0, -2) : this.objFooter.objPropDetails.Address;
                          this.objFooter.objPropDetails.Address = this.objFooter.objPropDetails.Address.trim().replace(/,{1,}$/, '');
                          localStorage["Crs"]=this.objFooter.objPropDetails.CRSInterface;
                          sessionStorage.setItem("PropDetails", JSON.stringify(message))                          
                          this.objLinks=JSON.parse(localStorage["HFLinks"]);
                        },(error)=>{ 
                          this.writeException(error,this.clsProp);
                        });
  }
   
  addSeperator(value : any){
    if(value!='')
    {
       return value + ','
    }
    else
    {
       return ''
    }
  }

  writeException(error : any ,data :any)
  {
    //this.toastr.info("Status : "+error.status+" "+error.statusText)       
    this.AngularException.set(error,"app-footer.component.ts"); 
    this.AngularException.data=JSON.stringify(data);
    this.ResultService.LogErrorAngToText(this.AngularException);
  }
}
