import { Component, OnInit } from '@angular/core';
import { DataProperty }      from './../../model/service-path'
import { ServicePath,AngularException }         from './../../model/service-path'
import { Router}              from '@angular/router'
import { ResultService}        from '../../../roomavailablity/services/services.result'
import  * as $ from 'jquery';
import 'hammerjs';
import { Subscription } from 'rxjs';
import { Lightbox, LightboxConfig, LightboxEvent, LIGHTBOX_EVENT, IEvent, IAlbum } from 'ngx-lightbox';
@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css'],
  host: {
    class: 'columns'
  }
})

export class GalleryComponent implements OnInit {
  public albums: Array<IAlbum>;
  private _subscription: Subscription;
   imgArray:any
   propertyGallery:any
   galleryImages;any
   
  constructor(
    private _lightbox: Lightbox,
    private _lightboxEvent: LightboxEvent,
    private _lighboxConfig: LightboxConfig,
    private clsProp         : DataProperty,
    public  servicePath     : ServicePath,
    public AngularException : AngularException,
    public ObjResultService    : ResultService,
    public router           : Router,
  ) {
   

    // set default config
    this._lighboxConfig.fadeDuration = 1;
  }
  ngOnInit(){
    try{
      this.albums = [];
      //this.imgArray=sessionStorage["gallerySessProp"].split(',');
      
      // for (let i = 0; i <= this.imgArray.length-1; i++) {
      //   const src =  this.imgArray[i];
      //   const caption =   this.imgArray[i] ;
      //   const thumb =  this.imgArray[i] ;
      //   const album = {
      //      src: src,
      //      caption: "",
      //      thumb: thumb
      //   };
  
      //   this.albums.push(album);
      // }
      this.getPhotoGalleryImages()
    }
    catch{}    
  }

  open(index: number): void {
    this._subscription = this._lightboxEvent.lightboxEvent$.subscribe((event: IEvent) => this._onReceivedEvent(event));

    // override the default config
    this._lightbox.open(this.albums, index, { wrapAround: true, showImageNumberLabel: true });
  }

  private _onReceivedEvent(event: IEvent): void {
    if (event.id === LIGHTBOX_EVENT.CLOSE) {
      this._subscription.unsubscribe();
    }
  }

  getPhotoGalleryImages()
  {
    this.clsProp.PropertyId=localStorage["PropertyId"];
    this.ObjResultService.getPhotoGalleryImages(this.clsProp)
                      .subscribe((response)=>{                 
                       this.galleryImages=response 
                       this.propertyGallery=[
                        this.checkType(this.galleryImages.image1),
                        this.checkType(this.galleryImages.image2),
                        this.checkType(this.galleryImages.image3),
                        this.checkType(this.galleryImages.image4),
                        this.checkType(this.galleryImages.image5),
                        this.checkType(this.galleryImages.image6),
                        this.checkType(this.galleryImages.image7),
                        this.checkType(this.galleryImages.image8),
                        this.checkType(this.galleryImages.image9)                       
                       ]

                    this.imgArray=this.propertyGallery.filter(word => word.length > 0);
                    //console.log(this.propertyGallery)
                    sessionStorage["gallerySessProp"]=this.propertyGallery;
                    // this.galleryImages = this.propertyGallery.map(value => {
                    //                       return { 
                    //                         small : value,
                    //                         medium :  value,
                    //                         big :  value };
                    // });

                    for (let i = 0; i <= this.imgArray.length-1; i++) {
                      const src =  this.imgArray[i];
                      const caption =   this.imgArray[i] ;
                      const thumb =  this.imgArray[i] ;
                      const album = {
                         src: src,
                         caption: "",
                         thumb: thumb
                      };
                
                      this.albums.push(album);
                    }

                       //console.log(response)
                       },(error)=>{ 
                        this.writeException(error,this.clsProp);
                       });
  }

  checkType(imageName : any) : string
  {
    if(imageName!="" && imageName!=undefined)
    {
      return this.servicePath.ImagePath+'/'+imageName;
    }
    else
    {
      return '';//this.servicePath.ImagePath+'/'+this.servicePath.noImageCart;
    }
  }

  writeException(error : any ,data :any)
  {
    //this.toastr.info("Status : "+error.status+" "+error.statusText)       
    this.AngularException.set(error,"app-header.component.ts"); 
    this.AngularException.data=JSON.stringify(data);
    this.ObjResultService.LogErrorAngToText(this.AngularException);
  }
}

