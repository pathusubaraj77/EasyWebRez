import { Component, OnInit } from '@angular/core';
import{ ServicePath } from '../../../shared/model/service-path'

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {
  prop: any
  constructor(public path:ServicePath) { }

  ngOnInit() {
    this.prop=JSON.parse(sessionStorage["PropDetails"])
  }
}
