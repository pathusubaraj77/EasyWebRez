import { Component, Inject, OnInit,ViewChild, TemplateRef } from '@angular/core';
import { Ng4GeoautocompleteModule } from 'ng4-geoautocomplete';
import { FormsModule } from '@angular/forms';
import{ResultService}        from '../../../roomavailablity/services/services.result'
import { DataProperty }      from './../../model/service-path'

@Component({
  selector: 'app-page-404',
  templateUrl: './page-404.component.html',
  styleUrls: ['./page-404.component.css'],
  
})
export class Page404Component implements OnInit {
  public componentData1: any = '';
  public Lat :any=[];
  public Lng :any=[];
  Address :any
  tittle : any ="";
  tempNo : any ="";
  public Text : string =""
   template4= "";
   context5 :any 
  public userSettings2: any = {
    showRecentSearch: false,
    geoCountryRestriction: ['in'],
    searchIconUrl: 'http://downloadicons.net/sites/default/files/identification-search-magnifying-glass-icon-73159.png'
  };
  public userSettings3: any = {
    showCurrentLocation: true,
    resOnSearchButtonClickOnly: true,
    inputPlaceholderText: 'Type anything and you will get a location',
    recentStorageName: 'componentData3',
    geoRadius: 5
  };
  public userSettings4: any = {
    showSearchButton: false,
    currentLocIconUrl: 'https://cdn4.iconfinder.com/data/icons/proglyphs-traveling/512/Current_Location-512.png',
    locationIconUrl: 'http://www.myiconfinder.com/uploads/iconsets/369f997cef4f440c5394ed2ae6f8eecd.png',
    recentStorageName: 'componentData4',
    noOfRecentSearchSave: 8
  };
  public userSettings5: any = {
    geoCountryRestriction: ['in'],
    geoTypes: ['establishment']
  };
  public userSettings6: any = {
    geoLocation: [37.76999, -122.44696],
    geoRadius: 5
  };
  public userSettings7: any = {
    useGoogleGeoApi: false,
    geoLocDetailServerUrl: 'https://www.simplymovein.com/api/v4/get-location',
    geoPredictionServerUrl: 'https://www.simplymovein.com/api/v4/search-location',
    geoLatLangServiceUrl: 'https://www.simplymovein.com/api/v4/geocode',
    serverResponseListHierarchy: ['data', 'items'],
    serverResponseatLangHierarchy: ['data'],
    serverResponseDetailHierarchy: ['data'],
    recentStorageName: 'componentData5'
  };

  public userSettings7_1: any = {
    useGoogleGeoApi: false,
    geoLocDetailServerUrl: 'https://www.XXX.com/api/v4/get-location',
    geoPredictionServerUrl: 'https://www.XXX.com/api/v4/search-location',
    geoLatLangServiceUrl: 'https://www.XXX.com/api/v4/geocode',
    serverResponseListHierarchy: ['data', 'items'],
    serverResponseatLangHierarchy: ['data'],
    serverResponseDetailHierarchy: ['data'],
    recentStorageName: 'componentData5'
  };

  constructor( public ResultService    : ResultService,
              private clsProp         : DataProperty) {
    this.tittle="Welcome"
    setTimeout(() => {
      this.userSettings3['inputPlaceholderText'] = 'This is delayed test';
      this.userSettings3 = Object.assign({}, this.userSettings3);
    }, 5000);0
   setTimeout(() => {
      this.userSettings3['inputString'] = 'Bangalore, karnataka';
      this.userSettings3 = Object.assign({}, this.userSettings3);
    }, 10000);
  }

thenTemplate:TemplateRef<any>|null=null;
@ViewChild('primaryTemplate')
primaryTemplate:TemplateRef<any>|null=null;

@ViewChild('secondaryTemplate')
secondaryTemplate:TemplateRef<any>|null=null;

@ViewChild('elseTemplate')
elseTemplate:TemplateRef<any>|null=null;

show : boolean ;
switchThenTemplate(template) 
{
    // this.thenTemplate= 
    // (this.thenTemplate===this.primaryTemplate) ?
    // this.secondaryTemplate:
    // this.primaryTemplate;

    if(template=='Primary')
    {
      this.show=true;
      this.thenTemplate=this.primaryTemplate
    }
    else if(template=='Secondary')
    {
      this.show=true;
      this.thenTemplate=this.secondaryTemplate
    }
    else
    {
      this.show=false;
    }
}
temp :any
tempNos : boolean =false 
  ngOnInit() {

    //this.thenTemplate=this.primaryTemplate;
    this.Text="@Its Worker SEEEEEEEEEEEEEEEEEEEEeeeeeeeeeeeeeeeeeEEEEEEE";
    this.context5 = this;
    this.template4 = `
    
    <div style="background-color: #b8c6cd; font-weight: bold;">
    Scope value: {{ Text }}
    </div>
    `;
  this.tempNo=this.template4;
  this.clsProp.PropertyId=1967;
  this.clsProp.PMSFolder="pms";
    this.ResultService.getPropertyDetails(this.clsProp)
                      .subscribe((message)=>
                      {
                      this.temp=message;
                      //alert(this.temp.Phone) 
                      this.show=true;
                      this.tempNos=true;
                      this.thenTemplate=this.primaryTemplate
                      }); 
  }
  getCodeHtml(data: any): any {
    let _temp: any = JSON.stringify(data);
    _temp = _temp.split(',').join(',<br>');
    _temp = _temp.split('{').join('{<br>');
    _temp = _temp.split('}').join('<br>}');
    return _temp;
  }
  autoCompleteCallback1(data: any): any {
   
    this.componentData1 = JSON.stringify(data);
    this.Lat = data.data.geometry.location.lat
    this.Lng = data.data.geometry.location.lng
    this.Address=data.data.formatted_address;
    localStorage["geoAddress"]=this.Address.split(',');
    let addresss=[];
    try
    {
      data.data.address_components.filter(function(item){
        if(item.types[0]=='locality') //sublocality_level_3 , administrative_area_level_3
        {
        addresss.push({City : item.long_name})
        }
        if(item.types[0]=='colloquial_area') //sublocality_level_3 , administrative_area_level_3
        {
          addresss.push({ City2 : item.long_name})
        }        
        else if(item.types[0]=='administrative_area_level_1') //State
        {
        //searchKeyword=searchKeyword==''?item.long_name : searchKeyword+','+item.long_name 
        addresss.push({ State : item.long_name})      
        }
        else if(item.types[0]=='country') //country
        {
        //searchKeyword=searchKeyword==''?item.long_name : searchKeyword+','+item.long_name 
        addresss.push({ Country : item.long_name})         
        }
        })
      console.log(addresss)

        // localStorage["location"]=searchKeyword;
        // let locationSearch=(
        //   {
        //     'searchKeyword':searchKeyword,
        //     'searchword' : data.data.formatted_address
        //   }
        // )
        // localStorage["location"]=JSON.stringify(locationSearch);
    }
    catch{}
  }

  userSettings ={
    inputPlaceholderText: 'This is the placeholder text doring component initialization'
    
  }
}

import { Directive, ElementRef} from '@angular/core';
@Directive({
   selector: '[changeText]',
   
})

export class ChangeTextDirective {
   constructor(Element: ElementRef) {
      console.log(Element);
      Element.nativeElement.innerText="Text is changed by changeText Directive.";
      Element.nativeElement.append('{{tittle}}')
   }
}
