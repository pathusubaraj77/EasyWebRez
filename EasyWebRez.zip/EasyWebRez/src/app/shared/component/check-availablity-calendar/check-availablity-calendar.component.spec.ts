import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckAvailablityCalendarComponent } from './check-availablity-calendar.component';

describe('CheckAvailablityCalendarComponent', () => {
  let component: CheckAvailablityCalendarComponent;
  let fixture: ComponentFixture<CheckAvailablityCalendarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckAvailablityCalendarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckAvailablityCalendarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
