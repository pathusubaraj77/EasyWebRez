import {Component,OnInit} from '@angular/core';
import {NgbDateStruct, NgbCalendar,NgbDatepickerConfig} from '@ng-bootstrap/ng-bootstrap';
import {BlockRoomsRequest} from './../../model/dataProperty'
import {AngularException}         from './../../model/service-path'
import {ResultService} from './../../../roomavailablity/services/services.result'
import {DataProperty} from './../../../shared/model/dataProperty'

const equals = (one: NgbDateStruct, two: NgbDateStruct) =>
  one && two && two.year === one.year && two.month === one.month && two.day === one.day;

const before = (one: NgbDateStruct, two: NgbDateStruct) =>
  !one || !two ? false : one.year === two.year ? one.month === two.month ? one.day === two.day
    ? false : one.day < two.day : one.month < two.month : one.year < two.year;

const after = (one: NgbDateStruct, two: NgbDateStruct) =>
  !one || !two ? false : one.year === two.year ? one.month === two.month ? one.day === two.day
    ? false : one.day > two.day : one.month > two.month : one.year > two.year;

@Component({
  selector: 'app-check-availablity-calendar',
  templateUrl: './check-availablity-calendar.component.html',
  styleUrls: ['./check-availablity-calendar.component.css']
})
export class CheckAvailablityCalendarComponent implements OnInit {

  hoveredDate: NgbDateStruct;

  fromDate: NgbDateStruct;
  toDate: NgbDateStruct;
  blockdates :any
  isCalendar : boolean;
  blockdateArray: any =[]
  model: NgbDateStruct;
  minDate : any
  constructor(public calendar: NgbCalendar,
    public objBlockRoomsRequest : BlockRoomsRequest,
    private objResultService : ResultService,
    public AngularException :AngularException,
    private clsProp          : DataProperty,
    public config: NgbDatepickerConfig) {
      this.isCalendar=false;
      this.minDate=this.calendar.getToday();
    //this.fromDate = calendar.getToday();
    //this.toDate = calendar.getNext(calendar.getToday(), 'd', 10);
  }

  onDateSelection(date: NgbDateStruct) {
    if (!this.fromDate && !this.toDate) {
      this.fromDate = date;
    } else if (this.fromDate && !this.toDate && after(date, this.fromDate)) {
      this.toDate = date;
    } else {
      this.toDate = null;
      this.fromDate = date;
    }
  }

  
  isWeekend(date: NgbDateStruct) {
    const d = new Date(date.year, date.month - 1, date.day);
    let datestring= d.getMonth()+1+'/'+d.getDate()+'/'+d.getFullYear();
    let test=this.blockdateArray.indexOf(datestring)
    return test!=-1 ?true :false;
  }

  isDisabled(date: NgbDateStruct) {
    const d = new Date(date.year, date.month - 1, date.day);
    return d.getDay() === 0 || d.getDay() === 6   //date.month !== current.month;
  }

  isHovered = date => this.fromDate && !this.toDate && this.hoveredDate && after(date, this.fromDate) && before(date, this.hoveredDate);
  isInside = date => after(date, this.fromDate) && before(date, this.toDate);
  isFrom = date => equals(date, this.fromDate);
  isTo = date => equals(date, this.toDate);
 

  ngOnInit() {
    this.clsProp.PropertyId=localStorage["PropertyId"] 
    this.GetBlockRoomDetails();
 
  }

  GetBlockRoomDetails()
  {
    const d1= this.calendar.getToday();
    const d2 = this.calendar.getNext(this.calendar.getToday(), 'y', 2);
    
    let fromBlockdate= d1.month+'/'+d1.day+'/'+d1.year;
    let toBlockdate= d2.month+'/'+d2.day+'/'+d2.year;;

    this.objBlockRoomsRequest.fromDate=fromBlockdate
    this.objBlockRoomsRequest.toDate=toBlockdate
    this.objBlockRoomsRequest.propertyId=this.clsProp.PropertyId;
    this.objBlockRoomsRequest.roomId=localStorage["RoomId"];
    this.objResultService.GetBlockRoomDetails(this.objBlockRoomsRequest)
    .subscribe((message)=>
    { 
      this.blockdates=message.filter(obj=>obj.roomId==localStorage["RoomId"])
      
      this.blockdateArray = this.blockdates.map(value => {
        // return { 
        // d     : new Date(value.blockDate.split(' ')[0]),
        // year  : new Date(value.blockDate.split(' ')[0]).getFullYear(),
        // month : new Date(value.blockDate.split(' ')[0]).getMonth()+1,
        // date  : new Date(value.blockDate.split(' ')[0]).getDate(),
        // day   : new Date(value.blockDate.split(' ')[0]).getDay()};
        // }
       // return new Date(value.blockDate.split(' ')[0])
          return  new Date(value.blockDate.split(' ')[0]).getMonth()+1+'/'+
                  new Date(value.blockDate.split(' ')[0]).getDate()+'/'+
                  new Date(value.blockDate.split(' ')[0]).getFullYear()
        
          
  
      });

      this.isCalendar=true;   

    // weekends are disabled
    // this.config.markDisabled = (date: NgbDateStruct) => {
    //   const d = new Date(date.year, date.month - 1, date.day);
    //   return d.getDay() === 0 || d.getDay() === 6;
    // };
    
      //console.log( this.blockdates)
      //console.log( this.blockdateArray)
    },(error)=>{ 
      this.writeException(error,this.clsProp);
    });
  }

  writeException(error : any ,data :any)
  {
    //this.toastr.info("Status : "+error.status+" "+error.statusText)       
    this.AngularException.set(error,"app-footer.component.ts"); 
    this.AngularException.data=JSON.stringify(data);
    this.objResultService.LogErrorAngToText(this.AngularException);
  }

}