export  class Header 
{
    images :any=[]
    ImagePath : string=""
    id :any = 1578
    galleryImages : any =[];
    isCrsFlow : boolean =false
    header : any=[]
    propDetails : any =[]
    logoImage : string =""
    phone : string = ""
}
