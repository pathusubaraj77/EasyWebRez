export  class Footer 
{
    objPropDetails: any =[];
    propDetails : string ='';
    isCrsFlow : boolean =false;
}
