export class ServicePath
{

    
    // port="http://192.168.1.200/EasyWebRezAPI/"

    port="http://localhost:49372/"  
    ImagePath="http://192.168.1.200/PMS/images/EIKCLOUD"; 
    ImagePathShoppingCart="http://192.168.1.200/PMS/EIK_ASP_PMS/Admin/Images/EIKCLOUD/"
    pmsSetupUrl="https://gracebeta.com/PMSUI-TRUNK/EasyInnKeeping/EasyInnKeeping.Web/MasterSetup/PropertyDetails?ID=0&CRSInterface=true"
    helpPage="http://gracebeta.com/crs/getgobnb.html"
    customHeaderPath="http://192.168.1.200/PMS-SVN/OnlineBookingV3/header/"    

    // port="http://gracebeta.com/PMS-SVN/EasyWebRezAPI/"     
    // ImagePath="http://gracebeta.com/PMS-SVN/images/EIKCLOUD";  
    // ImagePathShoppingCart="http://gracebeta.com/PMS-SVN/EIK_ASP_PMS/Admin/Images/EIKCLOUD/"
    // pmsSetupUrl="https://gracebeta.com/PMSUI-SVN/EasyInnKeeping/EasyInnKeeping.Web/MasterSetup/PropertyDetails?ID=0&CRSInterface=true"
    // helpPage="http://gracebeta.com/crs/getgobnb.html" 
    // customHeaderPath="http://gracebeta.com/PMS-SVN/OnlineBookingV3/header/" 

    // port="http://gracebeta.com/PMS-TRUNK/EasyWebRezAPI/"      
    // ImagePath="http://gracebeta.com/PMS-TRUNK/images/EIKCLOUD";  
    // ImagePathShoppingCart="http://gracebeta.com/PMS-TRUNK/EIK_ASP_PMS/Admin/Images/EIKCLOUD/"
    // pmsSetupUrl="https://gracebeta.com/PMSUI-TRUNK/EasyInnKeeping/EasyInnKeeping.Web/MasterSetup/PropertyDetails?ID=0&CRSInterface=true"
    // helpPage="http://gracebeta.com/crs/getgobnb.html"
    // customHeaderPath="http://gracebeta.com/PMS-Trunk/OnlineBookingV3/header/"

    // port="https://apps.gracesoft.com/PMS/EasyWebRezAPI/"     
    // ImagePath="https://apps.gracesoft.com/PMS/images/EIKCLOUD";
    // ImagePathShoppingCart="https://apps.gracesoft.com/PMS/EIK_ASP_PMS/Admin/Images/EIKCLOUD/"
    // pmsSetupUrl="https://apps.gracesoft.com/PMSUI/EasyInnKeeping/EasyInnKeeping.Web/MasterSetup/PropertyDetails?ID=0&CRSInterface=true"
    // helpPage="http://gracebeta.com/crs/getgobnb.html"
    // customHeaderPath="https://apps.gracesoft.com/PMS/OnlineBookingV3/header/"

    noImagecrsresult="ImageNotAvalilable.jpeg";
    noImagecrsroomdetails="img-not-roomdetilscrs.jpg"
    crsSearchBackgraoundImage="search-bg.jpg"
    crsOwnerDefaultImage='Owner-DefaultImage.png' 
    easyInKeepingLogo="EasyInnKeeping-logo2.png"
    crsLazyloaderImage="crsLazyloaderImage.jpg"
    noImageCart="picNotAvailable.jpg"

    CrsPropertySearch=this.port+"api/CrsPropertySearch/";
    RoomDetails=this.port+"api/RoomDetails/";
    SearchResult=this.port+"api/SearchResult/";
    ShoppingCart=this.port+"api/ShoppingCart/";
    ThankYouBooing=this.port+"api/ThankYouBooing/";
    CheckOut=this.port+"api/CheckOut/";
}

export class DataProperty
{
    public  PropertyId : number
    public  PMSFolder : string ="PMS"
}

export class AngularException
{
    PropertyId : any
    status     : any
    ok         : any
    statusText : any
    type       : any
    url        : any
    message    : any
    data       : any
    email      : string

    set(error :any,message : string){
        this.status=error.status;
        this.statusText=error.statusText
        this.url=error.url;
        this.PropertyId=localStorage["PropertyId"]
        this.message=message;  
        this.email="ewrdev3@gmail.com"  
    }
}

