export class DataProperty
{
    public  PropertyId : number
    public  PMSFolder : string="PMS"
}

export class BlockRoomsRequest
{
    public  fromDate :string
    public  propertyId :any
    public roomId :string
    public  toDate :string
}
