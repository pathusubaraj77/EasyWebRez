import { FormsModule }          from '@angular/forms';
import { BrowserModule }        from '@angular/platform-browser';
import { RouterModule} from '@angular/router';
import { AppHeaderComponent}    from './component/app-header/app-header.component'
import { AppFooterComponent}    from './component/app-footer/app-footer.component'
//import { RoomDetailsComponent } from  './../roomavailablity/component/room-details/room-details.component';
import { NgbdDatepickerRange} from './../shared/component/datepicker-range/datepicker-range.component'
import { SharedService}         from './services/shared.service'
import { ServicePath}           from './model/service-path'
import { Header}                from './model/header'
import { DataProperty}          from './model/service-path'
import {BlockRoomsRequest} from './model/dataProperty'
import { Footer} from './model/footer'
import { NgModule }             from '@angular/core';
import { NgbModule,NgbDateParserFormatter,NgbDatepickerConfig, NgbInputDatepicker } from '@ng-bootstrap/ng-bootstrap' 
//import { NgbDate } from '@ng-bootstrap/ng-bootstrap/datepicker/ngb-date';
import { NgxGalleryModule } from 'ngx-gallery';
import {CustomNgbDateParserFormatter} from './model/custom-ngbDateParserFormatter';
import { CrsHeaderComponent } from './component/crs-header/crs-header.component';
import { CrsFooterComponent } from './component/crs-footer/crs-footer.component';
import { Page404Component,ChangeTextDirective} from './component/page-404/page-404.component';
import { Ng4GeoautocompleteModule } from 'ng4-geoautocomplete';
import { AboutComponent } from './component/about/about.component';
import { GalleryComponent } from './component/gallery/gallery.component';
import { LightboxModule } from 'ngx-lightbox';
import {CheckAvailablityCalendarComponent} from './component/check-availablity-calendar/check-availablity-calendar.component';
 

@NgModule({
imports: [ FormsModule,BrowserModule,NgbModule.forRoot(),NgxGalleryModule,LightboxModule,
          Ng4GeoautocompleteModule.forRoot(),
          RouterModule.forChild([
          {path: 'header', component: AppHeaderComponent},
          {path: 'footer', component: AppFooterComponent},
          {path: 'datepicker', component: NgbdDatepickerRange},
          {path: 'crs-header', component: CrsHeaderComponent},
          {path: 'crs-footer', component: CrsFooterComponent},
          {path: '404', component: Page404Component},
          {path: 'gallery', component: GalleryComponent},
          {path: 'about', component: AboutComponent},
          {path: 'cal', component: CheckAvailablityCalendarComponent}
       ])        
        ],
     declarations :[AppHeaderComponent,AppFooterComponent,GalleryComponent,
          NgbdDatepickerRange, CrsHeaderComponent, CrsFooterComponent,ChangeTextDirective,
          Page404Component, AboutComponent,CheckAvailablityCalendarComponent],

         //providers:[SharedService]
         exports :[AppHeaderComponent,AppFooterComponent,NgbdDatepickerRange,CrsHeaderComponent,Ng4GeoautocompleteModule,
          CrsFooterComponent,CheckAvailablityCalendarComponent],
         providers:[SharedService,ServicePath,Header,DataProperty,Footer,BlockRoomsRequest,
          NgbDatepickerConfig,GalleryComponent,NgbInputDatepicker,
           // {provide: NgbDateParserFormatter, useFactory: () => new CustomNgbDateParserFormatter('MM/dd/yyyy')}
         ]
})
export  class SharedModule{}


