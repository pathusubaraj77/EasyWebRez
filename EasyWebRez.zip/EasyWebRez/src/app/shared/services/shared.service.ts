import {Injectable} from '@angular/core';
import {Http,Response,RequestOptions,Headers} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import {ServicePath} from './../model/service-path'


@Injectable()
export class SharedService {
  constructor( private http:Http,private servicePath : ServicePath){ }  

  //Get footer and property details
  getPropertyDetails(objDatarop : object) :Observable<object> 
  {
    let headers= new Headers({'Content-Type' : 'application/json; charset=utf-8'});   
    let options=new RequestOptions({
        headers : headers,
    });       
    return this.http.post(this.servicePath.RoomDetails+'GetHotelDetails',
                    JSON.stringify(objDatarop),options)
                    .map((responce:Response) => <object>responce.json());
  }

  //header details
  getHeaderDetails(body:any) : Observable<any> 
  {
    let headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8' });
    let options = new RequestOptions({ headers: headers});

    return this.http.post(this.servicePath.RoomDetails+'GetTemplateSettings',
                    JSON.stringify(body),options)
                    .map((response:Response)=><any>response.json());
  }
}
