
export class Rateproperty {
    public ArrDate :string
    public  DeptDate :string
    public  Gid : any
    public  NoOfChild :any
    public  NoOfGuests : number
    public  PropertyId : any
    public  RoomId : number

    set(objRate : any){
        this.RoomId=objRate.RoomId,
        this.PropertyId = objRate.PropertyId,
        this.Gid = objRate.Gid,
        this.NoOfChild = 0,
        this.NoOfGuests = 1
    }
    
    setDate(NoOfGuests : any)
    {
        this.ArrDate=localStorage["checkIn"]  
        this.DeptDate=localStorage["checkOut"]
        if(localStorage["dateFormat"]=='dd/mm/yy')
        {
            let df = localStorage["checkIn"].split('/');
            let dt = localStorage["checkOut"].split('/');
           
            this.ArrDate=df[1]+'/'+df[0]+'/'+df[2]
            this.DeptDate=dt[1]+'/'+dt[0]+'/'+dt[2]        
        }
        this.NoOfGuests=NoOfGuests
    }
}
