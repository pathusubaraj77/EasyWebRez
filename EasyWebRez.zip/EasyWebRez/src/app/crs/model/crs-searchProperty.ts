export class CrsSearchProperty
{
    SearchKeyword : string
    PropertyType  : string
    CRSFilter     : string
    RateFilter  :string
    AmenFilter :string
    PropertyId    : number
    directland : boolean =false
    RoomId : any
    ObjAreaSearch : any

    set(AmenFilter : string){
        this.PropertyType=""
        this.SearchKeyword=localStorage["location"]
        this.AmenFilter=AmenFilter
        this.RateFilter=""        
    } 
}