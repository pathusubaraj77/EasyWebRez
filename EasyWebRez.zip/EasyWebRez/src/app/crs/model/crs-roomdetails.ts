
export class CrsRoomsdetails
{
    noOfnights : any
    baseamount : number
    imagePath :string
    set_noOfNights(checkIn : string,checkOut : string)
    {    
     let diffInMs: number =  Date.parse(checkOut) -Date.parse(checkIn)
     let diffInHours: number = diffInMs / 1000 / 60 / 60;
     this.noOfnights=(diffInHours/24); 
    }

    set_baseAmount(baseamount :any)
    {
        this.baseamount=baseamount;
    }
}