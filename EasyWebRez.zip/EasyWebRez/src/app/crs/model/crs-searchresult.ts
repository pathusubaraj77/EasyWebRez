export class CrsSearchResult
{
    PropertyId : number
    PropertyName :string
    Currency :string
    RoomTypeName :string
    RoomName :string
    Amenities : string
    Rate : any
    ImageName : string
    NoOfGuests : number
    NoOfBedRooms : number
    NoOfBeds : number
    NoOfBathRooms  : number
    BathRoomType : string
    imagePath:string

    amenities : any =
    [                    
        {name:'Swimming Pool',value:"',' + Amenities + ',' like '%,Swimming Pool,%' "},
        {name:'Essentials',value:"',' + Amenities + ',' like '%,Essentials,%' "},
        {name:'Kitchen',value:"',' + Amenities + ',' like '%,Kitchen,%' "},
        {name:'AC',value:"',' + Amenities + ',' like '%,AC,%' "},
        {name:'WiFi',value:"',' + Amenities + ',' like '%,WiFi,%' "},
        {name:'TV',value:"',' + Amenities + ',' like '%,TV,%' "},
        {name:'Closet/ Drawers',value:"',' + Amenities + ',' like '%,Closet/ Drawers,%' "},
        {name:'Desk/ Workspace',value:"',' + Amenities + ',' like '%,Desk/ Workspace,%' "},
        {name:'Breakfast',value:"',' + Amenities + ',' like '%,Breakfast,%' "},
        {name:'Hair Dryer',value:"',' + Amenities + ',' like '%,Hair Dryer,%' "},
        {name:'Iron',value:"',' + Amenities + ',' like '%,Iron,%' "},
        {name:'Washer',value:"',' + Amenities + ',' like '%,Washer,%' "}
    ]     

    rates : any =
    [      
        {name :'0 - 100',value :"Rate Between 0 and 100"},
        {name :'100 - 200',value :"Rate Between 100 and 200"},
        {name :'200 - 500',value :"Rate Between 200 and 500"},
        {name :'500 - 1000',value :"Rate Between 500 and 1000"}
    ]
}
