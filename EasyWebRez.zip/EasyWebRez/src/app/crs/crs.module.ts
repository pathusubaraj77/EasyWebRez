import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { CrsSearchComponent } from './component/crs-search/crs-search.component';
import { CrsSearchresultComponent } from './component/crs-searchresult/crs-searchresult.component';
import { CrsRoomdetailsComponent } from './component/crs-roomdetails/crs-roomdetails.component';
import { CrsService} from './services/crs-search.service'
//import { NgAutoCompleteModule } from "ng-auto-complete";
import { CrsSearchProperty} from './../crs/model/crs-searchProperty'
import { Rateproperty } from './model/rateproperty'
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbdTypeaheadBasic } from './component/ngbd-typeahead-basic/ngbd-typeahead-basic.component';
import {SharedModule} from './../shared/shared.module'
import {CrsRoomsdetails} from './model/crs-roomdetails'
import {CrsSearchResult} from './model/crs-searchresult'
import{ListAPropertyComponent} from './component/list-a-property/list-a-property.component';
import { AgmCoreModule } from '@agm/core';
import { HelpComponent } from './component/help/help.component';
import { LazyLoadImageModule } from 'ng-lazyload-image';
import {AngularException} from './../shared/model/service-path'
import { NgxGalleryModule } from 'ngx-gallery';
import {AboutComponent} from './component/about/about.component';
@NgModule({
    imports : 
    [
        FormsModule,ReactiveFormsModule,HttpClientModule,
        SharedModule,
        NgxGalleryModule,
        BrowserModule,
        LazyLoadImageModule,
        NgbModule.forRoot(),
        RouterModule.forRoot([
            {path: 'crs',component:CrsSearchComponent},
            {path: 'crsresult',component : CrsSearchresultComponent},
            {path: 'crsroomdetails',component:CrsRoomdetailsComponent},
            {path: 'crsroomdetails/:pId/:rId',component:CrsRoomdetailsComponent},
            {path: '', redirectTo: 'crs', pathMatch: 'full' },
            {path: 'select',component:NgbdTypeaheadBasic},
            {path: 'list-property', component:ListAPropertyComponent },
            {path: 'help', component:HelpComponent },
            {path: 'about-Get-Go-Bnb', component: AboutComponent}
        ]),
        AgmCoreModule.forRoot({
            apiKey: 'AIzaSyAoL4mXo2Np88EwVjCt7oNQuztAiN7ROeI'
          }) 
    ],

    declarations : 
    [
        CrsSearchComponent, 
        CrsSearchresultComponent, 
        CrsRoomdetailsComponent, NgbdTypeaheadBasic, ListAPropertyComponent, HelpComponent,AboutComponent
    ],
    providers : 
    [
        CrsService,Rateproperty,
        CrsSearchProperty,CrsRoomsdetails,CrsSearchResult,AngularException
    ]
})
export  class CrsModule{}
