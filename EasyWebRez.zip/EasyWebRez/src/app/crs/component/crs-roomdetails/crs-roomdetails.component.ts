import { Component, OnInit, Input } from '@angular/core';
import {CrsService} from './../../services/crs-search.service'
import {CrsSearchProperty} from './../../model/crs-searchProperty'
import {ShopingCartService}       from './../../../checkout/services/shoping-cart.service'
import { Router, NavigationEnd ,ActivatedRoute }  from '@angular/router';
import {RoomsInputProperty} from './../../../roomavailablity/model/roomsInputProperty'

import { GroupBookingProp }         from './../../../roomavailablity/model/GroupBookingProperty'
import { RuleInputProperty }        from './../../../roomavailablity/model/ruleInputProperty'
import { Widget }                   from './../../../roomavailablity/model/widget'
import { DataProperty}              from './../../../roomavailablity/model/dataProperty'
import { SearchProp }               from './../../../roomavailablity/model/searchProperty'
import { ResultService }            from './../../../roomavailablity/services/services.result'
import { TempInputProp} from './../../../roomavailablity/model/tempInputProperty'
import { CrsRoomsdetails} from './../../model/crs-roomdetails'
import { Rateproperty } from './../../model/rateproperty'
import { ToastrService} from 'ngx-toastr';
import { ServicePath,AngularException } from './../../../shared/model/service-path'
import { NgxGalleryOptions, NgxGalleryImage, NgxGalleryAnimation } from 'ngx-gallery';


@Component({
  selector: 'app-crs-roomdetails',
  templateUrl: './crs-roomdetails.component.html',
  styleUrls: ['./crs-roomdetails.component.css']
})
export class CrsRoomdetailsComponent implements OnInit {
  imageName:string=""
  objRoomDetails:any=[]
  isButtondisabled=false
  roomImages: any ="";
  pId: any 
  rId: any 
  galleryOptions: NgxGalleryOptions[];
  roomImagesList:  NgxGalleryImage[];
  dynamicRate: any= 0;
  constructor(private objCrsService:CrsService,
              private objResultService:ResultService,
              private router          : Router,
              public objCrsSearchProp : CrsSearchProperty,
              public  inputProp        : RoomsInputProperty,
              private ruleInputProp  : RuleInputProperty,
              private groupInputProp : GroupBookingProp,
              public objWidget       : Widget,
              private clsProp        : DataProperty,
              private searchProp     : SearchProp,
              private objTempInputProp :TempInputProp,
              public objCrsRoom:CrsRoomsdetails,
              private toastr    : ToastrService,
              public ServicePath : ServicePath,
              public AngularException :AngularException,                            
              private route            : ActivatedRoute,
              private objShopingCartService : ShopingCartService,
              public objRateproperty : Rateproperty  
            ){
               objCrsRoom.imagePath=ServicePath.ImagePath;
               objWidget.noOfAdults=1;
               localStorage["PropertyType"]="Home";
               sessionStorage["ConfirmNo"]=0
               localStorage["crsFlow"]=true;

               this.route.params.subscribe( params =>{
                this.pId=params.pId
                this.rId=params.rId
              });
              if(this.pId!=undefined &&this.rId!=undefined){
                localStorage["PropertyId"]=this.pId
                localStorage["directLand"]=true
                localStorage["PropertyId"]=this.pId
                localStorage["RoomId"]=this.rId
                this.objCrsSearchProp.directland=true
                this.objCrsSearchProp.RoomId=this.rId;
                this.ruleInputProp.IsdirectLanding=true
                this.ruleInputProp.RoomId=this.rId
                localStorage["PropertyType"]="Hotel";
              }
             }

  ngOnInit() {

    try
    {
      localStorage.removeItem('checkIn');
      localStorage.removeItem('checkOut');
      this.getPropertyDetails();     
      this.clsProp.PropertyId=localStorage["PropertyId"];
      sessionStorage["RoomListId"]=sessionStorage["RoomListId"]==undefined ? "0" : sessionStorage["RoomListId"]
      sessionStorage["cartListId"]=sessionStorage["cartListId"]==undefined ? "0" : sessionStorage["cartListId"]

      if(sessionStorage["RoomListId"]!="0")
      {
        this.objResultService.removeSelectedRooms(this.clsProp,0)
                            .subscribe((response)=>{
                            },(error)=>{ 
                              this.writeException(error,this.clsProp);
                            });
    
      }       
      if(sessionStorage["cartListId"]!="0")
      {            
        let body =this.clsProp
        let sCartId = sessionStorage["cartListId"]
        this.objShopingCartService.removeCartList(body,sCartId,0)
                            .subscribe((response)=>{                          
                            },(error)=>{ 
                              this.writeException(error,body);
                            });
      }   
      
      this.router.events.subscribe((evt) => {
        if (!(evt instanceof NavigationEnd)) {
            return;
        }
        window.scrollTo(0, 0)
      });


      this.galleryOptions = [
        {
            width: '100%',
            height: '500px',
            thumbnailsColumns: 4,
            imageAnimation: NgxGalleryAnimation.Slide
        },
        {
            breakpoint: 800,
            width: '100%',
            height: '600px',
            imagePercent: 80,
            thumbnailsPercent: 20,
            thumbnailsMargin: 20,
            thumbnailMargin: 20
        },
        // max-width 
        {
            breakpoint: 400,
            preview: false
        }
    ];
    }
    catch{}     
  }
  arrayOne(n: number): any[] {
    return Array(n);
  }
  getPropertyDetails()
  {
    this.objCrsSearchProp.PropertyType=""
    this.objCrsSearchProp.SearchKeyword=""
    this.objCrsSearchProp.CRSFilter=""
    this.objCrsSearchProp.PropertyId= localStorage["PropertyId"]  
    this.objCrsService.getPropertyDetails(this.objCrsSearchProp)
                      .subscribe((response)=>{
                      this.objRoomDetails=response[0]
                      this.objWidget.noOfAdults=1;
                      this.objRateproperty.set(response[0])
                      localStorage["RateChangesObj"]=JSON.stringify(this.objRateproperty);
                      
                      this.roomImages=this.objRoomDetails.ImageName.split(',');
                      this.roomImages=this.roomImages.filter(word => word.length > 0);
                      if(this.rId!=undefined){
                        this.imageName=this.roomImages.length>0 ? encodeURI(this.roomImages[0]) : '';
                      }
                      else{
                        this.imageName=this.objRoomDetails.PropertyImageName!=''? encodeURI(this.objRoomDetails.PropertyImageName) : '';
                      }
                      this.imageName=this.imageName==''? this.ServicePath.noImagecrsroomdetails:this.imageName;
                      this.roomImagesList = this.roomImages.map(value => {
                                            return { 
                                              small : this.objCrsRoom.imagePath+'/'+value,
                                              medium :  this.objCrsRoom.imagePath+'/'+value,
                                              big :  this.objCrsRoom.imagePath+'/'+value };
                      });

                      this.objRoomDetails.Amenities=this.objRoomDetails.Amenities.split(',');
                      localStorage["PropertyName"]=this.objRoomDetails.PropertyName;
                      //console.log(response)
                      },(error)=>{ 
                        this.writeException(error,this.objCrsSearchProp);
                      });
  }

  searchAvailablity()
  { 
    this.isButtondisabled=true;

    this.objWidget.set_Date();

    if(this.objWidget.checkIn==this.objWidget.checkOut)
    {
      this.toastr.warning("Sorry please change checkout date");
      this.isButtondisabled=false;
      return false;
    }

    this.searchProp.set(this.objWidget.roomType,this.objWidget.checkIn,
    this.objWidget.checkOut,this.objWidget.noOfAdults)

    localStorage.setItem("SearchProp", JSON.stringify(this.searchProp));
    sessionStorage.setItem("InputProp", JSON.stringify(this.searchProp));
    
    this.ruleInputProp.set(this.searchProp,1,1,false,false);
    this.ruleInputProp.RoomType=this.objRoomDetails.RoomTypeName
    this.ruleInputProp.RoomId=this.objRoomDetails.RoomId
    this.groupInputProp.set(this.searchProp);
    this.groupInputProp.RoomType=this.objRoomDetails.RoomTypeName
    let body={"clsProp":this.clsProp,"inputProp" :this.ruleInputProp,"grouprop" : this.groupInputProp};
    this.objResultService.GetNormalRuleList(body)
        .subscribe((message)=>
          {
            this.objWidget.ruleResponce=message;      
            if(message=="")
            {
              this.objResultService.GetReservationRuleList(body)
              .subscribe((message)=>
                          {
                            this.objWidget.ruleResponce=message;
                            if(message.search("Error")==-1)
                            {
                            this.booknow();
                            }
                            else
                            {
                              this.toastr.warning(message.split("=")[1])
                              this.isButtondisabled=false
                            }
                            },(error)=>{ 
                              this.writeException(error,body);
                            });
            }
            if(message.search("Error")!=-1)
            {
              this.toastr.warning(message.split("=")[1])
              this.isButtondisabled=false
            }
          },(error)=>{ 
            this.writeException(error,body);
          });
  }

  booknow()
  {
    //this.objCrsRoom.set_noOfNights();
    //this.objRoomDetails.Rate=this.dynamicRate==0?(this.objRoomDetails.Rate * this.objCrsRoom.noOfnights) : this.objRoomDetails.Rate
    this.objCrsRoom.set_baseAmount(this.objRoomDetails.Rate);    
    this.objCrsRoom.set_noOfNights(this.objWidget.checkIn,this.objWidget.checkOut);
    
    this.inputProp.set(this.objWidget.checkIn,this.objWidget.checkOut,this.objWidget.noOfAdults,
    1,this.objRoomDetails.RoomTypeName,false,false,'roomno',sessionStorage["RoomListId"],
    
    this.objCrsRoom.noOfnights)
    sessionStorage["InputProp"]=JSON.stringify(this.inputProp);
    sessionStorage.Selectedroooms=this.objRoomDetails.RoomName;
    sessionStorage.NoOfRooms=1

    this.objTempInputProp.set('RoomName',sessionStorage["RoomListId"],[this.objRoomDetails.RoomId],[this.objRoomDetails.Gid],1,[this.objRoomDetails.RoomName],
    this.objRoomDetails.RoomTypeName,[this.objRoomDetails.ImageName],[this.objCrsRoom.baseamount],[''],[''],[''],[''],[''])

    let body=JSON.stringify({clsProp :this.clsProp,tempProp: this.objTempInputProp});

    //Adding selected rooms in temp rooms  
    this.objResultService.addToRoomList(body)
                         .subscribe((response)=>{                          
                          sessionStorage.setItem("RoomListId",response) 
                          this.router.navigate(['/reg'])       
                          },(error)=>{ 
                            this.writeException(error,JSON.parse(body));
                          });
    //selected rooms function end
  }
  
  writeException(error : any ,data :any)
  {
    this.toastr.info("Status : "+error.status+" "+error.statusText)       
    this.AngularException.set(error,"crs-roomdetails.component.ts"); 
    this.AngularException.data=JSON.stringify(data);
    this.objResultService.LogErrorAngToText(this.AngularException);
  }

  receiveRateChanges($event) {
    //this.dynamicRate = $event
    this.objRoomDetails.Rate=$event
  }

  getRatesChanges()
  {   
    this.objRateproperty.setDate(this.objWidget.noOfAdults);
    this.objResultService.getRatesChanges(this.objRateproperty)
    .subscribe((message)=>
    { 
      //this.dynamicRate=message;
      this.objRoomDetails.Rate=message;
    },(error)=>{ 
      this.writeException(error,this.clsProp);
    });
  }
} 
