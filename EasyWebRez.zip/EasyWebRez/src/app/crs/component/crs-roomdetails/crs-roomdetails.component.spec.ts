import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrsRoomdetailsComponent } from './crs-roomdetails.component';

describe('CrsRoomdetailsComponent', () => {
  let component: CrsRoomdetailsComponent;
  let fixture: ComponentFixture<CrsRoomdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrsRoomdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrsRoomdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
