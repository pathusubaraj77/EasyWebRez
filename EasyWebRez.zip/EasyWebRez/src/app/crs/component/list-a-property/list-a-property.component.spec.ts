import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListAPropertyComponent } from './list-a-property.component';

describe('ListAPropertyComponent', () => {
  let component: ListAPropertyComponent;
  let fixture: ComponentFixture<ListAPropertyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListAPropertyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListAPropertyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
