import { Component, OnInit } from '@angular/core';
import {ServicePath} from './../../../shared/model/service-path'

@Component({
  selector: 'app-list-a-property',
  templateUrl: './list-a-property.component.html',
  styleUrls: ['./list-a-property.component.css']
})
export class ListAPropertyComponent implements OnInit {

  constructor(public path :ServicePath) { }
  isLive : boolean =false
  ngOnInit() {
    if(this.path.port=="https://apps.gracesoft.com/PMS/EasyWebRezAPI/")
    {
      this.isLive=true;
    }else{
      this.isLive=false;
    }
  }

}
