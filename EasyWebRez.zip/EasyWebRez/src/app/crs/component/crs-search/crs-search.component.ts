import { Component, OnInit,ViewChild } from '@angular/core';
import { CrsService } from './../../services/crs-search.service'
import { Router} from '@angular/router'
import {CreateNewAutocompleteGroup, SelectedAutocompleteItem, NgAutocompleteComponent} from "ng-auto-complete";
import {ServicePath} from './../../../shared/model/service-path'
import { ToastrService} from 'ngx-toastr';
import * as $       from 'jquery';
@Component({
  selector: 'app-crs-search', 
  templateUrl: './crs-search.component.html',
  styleUrls: ['./crs-search.component.css']
})
export class CrsSearchComponent implements OnInit {
  location : string =""
  propertyAddress : any
  public selected: any[] = []; 
  isautoCompleteSelected =false
  constructor(private objCrsSearchService:CrsService,
              private router:Router,
              public ServicePath: ServicePath,
              private toastr    : ToastrService
            ) {
              localStorage.removeItem('location');
             }

  ngOnInit() {
    localStorage.clear();
    let body={"SearchKeyword":"","PropertyType":""}
    sessionStorage["RoomListId"]="0";
    sessionStorage["ConfirmNo"]=0
      localStorage["location"]=""
      localStorage["Crs"]=true
  }

  autoCompleteCallback1(data: any): any {
  this.isautoCompleteSelected=true;
    let searchKeyword=''
    let address: any =[];    
    try
    {
      data.data.address_components.filter(function(item){
        if(item.types[0]=='locality') // city
        {
        searchKeyword =item.long_name
        address.City = item.long_name;       
        }
        if(item.types[0]=='colloquial_area') // second city
        {
        searchKeyword =item.long_name
        address.City2 =item.long_name;       
        }        
        else if(item.types[0]=='administrative_area_level_1') //state
        {
        searchKeyword=searchKeyword==''?item.long_name : searchKeyword+','+item.long_name  
        address.State = item.long_name; 
        address.Stateshort_name =  item.short_name;  
        }
        else if(item.types[0]=='country') //country
        {
        searchKeyword=searchKeyword==''?item.long_name : searchKeyword+','+item.long_name    
        address.Country = item.long_name;
        address.Countryshort_name =  item.short_name; 
        }
        })

        localStorage["location"]=searchKeyword;
        let locationSearch={
            'searchKeyword':searchKeyword,
            'searchword' : data.data.formatted_address
        }
        localStorage["location"]=JSON.stringify(locationSearch);
        
        localStorage["locationAreaSearch"]=JSON.stringify(
        {
        'City' : address.City, 'City2' : address.City2,
        'State' : address.State,'Stateshort_name':address.Stateshort_name,
        'Country' : address.Country,'Countryshort_name' : address.Countryshort_name
        });

        console.log(address)
    }
    catch{}
  }

  Selected(item: SelectedAutocompleteItem) {
    //console.log(item);
  }

  search()
  {
    if(!this.isautoCompleteSelected)
    {
    this.toastr.info("Please enter City or State")
    }else{
    this.router.navigate(['/crsresult'])
    }  
  }
}
