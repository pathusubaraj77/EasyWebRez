import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrsSearchComponent } from './crs-search.component';

describe('CrsSearchComponent', () => {
  let component: CrsSearchComponent;
  let fixture: ComponentFixture<CrsSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrsSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrsSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
