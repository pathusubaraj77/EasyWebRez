import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrsSearchresultComponent } from './crs-searchresult.component';

describe('CrsSearchresultComponent', () => {
  let component: CrsSearchresultComponent;
  let fixture: ComponentFixture<CrsSearchresultComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrsSearchresultComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrsSearchresultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
