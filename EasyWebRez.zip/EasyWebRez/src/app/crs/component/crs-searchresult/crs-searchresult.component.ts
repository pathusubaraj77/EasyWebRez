import { Component, OnInit, ChangeDetectionStrategy ,ViewChild,AfterViewInit  } from '@angular/core';
import { CrsService } from './../../services/crs-search.service'
import { CrsSearchProperty } from './../../model/crs-searchProperty'
import {Router, NavigationEnd} from '@angular/router'
import { FormControl, FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import {CrsSearchResult} from './../../model/crs-searchresult'
import { ServicePath,AngularException } from './../../../shared/model/service-path'
import { MouseEvent } from '@agm/core';
import { ToastrService} from 'ngx-toastr';
import * as $       from 'jquery';
import 'rxjs/Rx'
import { GoogleMapsAPIWrapper, AgmMap, LatLngBounds, LatLngBoundsLiteral} from '@agm/core';
declare var google: any;
@Component({
  selector: 'app-crs-searchresult',
  templateUrl: './crs-searchresult.component.html',
  styleUrls: ['./crs-searchresult.component.css']
})
export class CrsSearchresultComponent implements OnInit,AfterViewInit  {
  
  zoom: number = 8;
  title: string = 'My first AGM project';
  lat: number;//=51.678418;
  lng: number;//=7.809007;
  objSearchResult :any
  location : string=""          
  myForm: FormGroup;
  myFormRate: FormGroup;
  noroomsAvailable : boolean 
  isAmendisabled : boolean
  isRatedisabled : boolean
  errorMessage : string=""
  isButtondisabled=false
  isautoCompleteSelected=false
  @ViewChild('AgmMap') agmMap: AgmMap;
  map:AgmMap
  bounds:any 
  clickedMarker(label: string, index: number) {
    //console.log(`clicked the marker: ${label || index}`)
  }
  
  mapClicked($event: MouseEvent) {
    // this.markers.push({
    //   lat: $event.coords.lat,
    //   lng: $event.coords.lng,
    //   draggable: true
    // });
    console.log('LatLng', $event);
  }

  mouseOver($event: MouseEvent) {
    //alert("")
  };
  
  
  markerDragEnd(m: marker, $event: MouseEvent) {
    //console.log('dragEnd', m, $event);
  }
  public markers: any =[];
  
  constructor(private objCrsService:CrsService,
              public objCrsSearchPro:CrsSearchProperty,
              private router:Router,
              private fb: FormBuilder,
              public objcrsResult:CrsSearchResult,
              public ServicePath : ServicePath,public AngularException :AngularException,
              private toastr    : ToastrService) 
              {
                objcrsResult.imagePath=ServicePath.ImagePath;
                this.noroomsAvailable=false
                this.isAmendisabled=false;
                this.isRatedisabled=false;                
              }  
              
  ngOnInit() {
    try
    {
        sessionStorage["crsFlow"]=false
        this.objCrsSearchPro.set("");
        this.myForm = this.fb.group({
          amenities: this.fb.array([])
        });     
        this.myFormRate = this.fb.group({
          rates: this.fb.array([])
        });
        
       
        this.getAllPropertyDetails();
    
        this.router.events.subscribe((evt) => {
          if (!(evt instanceof NavigationEnd)) {
              return;
          }
          window.scrollTo(0, 0)
        });
        $('#search_places').attr('placeholder','Enter City or State')

    }
    catch{}  
  }

  onChange(data:string, isChecked: boolean,filter:string) {
    const amenFormArray = <FormArray>this.myForm.controls.amenities;
    const ratesFormArray = <FormArray>this.myFormRate.controls.rates;
    let tempamenities=""

    if(filter=='amenities'){
      if(isChecked) {
        amenFormArray.push(new FormControl(data+'and'));
        this.myForm.value.amenities.forEach(function(i,n){ tempamenities=tempamenities+i+ ' ' })
        this.objCrsSearchPro.AmenFilter=tempamenities 
        this.objCrsSearchPro.set(this.objCrsSearchPro.AmenFilter)
        this.getAllPropertyDetails();
      }
      else 
      {
        let index = amenFormArray.controls.findIndex(x => x.value == data+'and')
        amenFormArray.removeAt(index);
        this.myForm.value.amenities.forEach(function(i,n){ tempamenities=tempamenities+i+ ' ' })
        this.objCrsSearchPro.AmenFilter=tempamenities 
        this.objCrsSearchPro.set(this.objCrsSearchPro.AmenFilter)
        this.getAllPropertyDetails();
      }
    }
    else if(filter=='rates')
    {
      if(isChecked) {
        ratesFormArray.push(new FormControl(data+' Or'));
        this.objCrsSearchPro.set(this.objCrsSearchPro.AmenFilter)
        this.objCrsSearchPro.RateFilter=this.myFormRate.value.rates.toString().split(',').join(' ');         
        this.getAllPropertyDetails();
      }
      else 
      {
        let index = ratesFormArray.controls.findIndex(x => x.value == data +' Or')
        ratesFormArray.removeAt(index);
        this.objCrsSearchPro.set(this.objCrsSearchPro.AmenFilter)
        this.objCrsSearchPro.RateFilter=this.myFormRate.value.rates.toString().split(',').join(' '); 
        this.getAllPropertyDetails();
      }
    }
 }

 mapIdle() {
  //console.log('idle');
}

 ngAfterViewInit() {
 }
  getAllPropertyDetails()
  {
    try
    {
      this.isAmendisabled=true;
      this.isRatedisabled=true; 
      this.isautoCompleteSelected=false
      let mapResult = []; 
      this.markers=[];
      this.bounds=[]
      this.location=JSON.parse(localStorage["location"]).searchKeyword;
      let searchword=JSON.parse(localStorage["location"]).searchword; 
      this.objCrsSearchPro.ObjAreaSearch=JSON.parse(localStorage["locationAreaSearch"]);
      this.objCrsSearchPro.SearchKeyword=this.location==undefined? "" : this.location
      this.objCrsService.getAllPropertyDetails(this.objCrsSearchPro)
                        .subscribe((response)=>{
                          this.objSearchResult=response
                          if(response.length==0) {this.noroomsAvailable=true}
                          else{this.noroomsAvailable=false}
                          this.isAmendisabled=false;
                          this.isRatedisabled=false; 
                          if(!this.isButtondisabled){ $('#search_places').val(searchword) }
                          this.isButtondisabled=false; 
                          
                          response.map((obj)=>{
                            if(obj.Latitude!='' && obj.Longitude!=''){
                              this.markers.push(
                                {
                                  lat : parseFloat(obj.Latitude),
                                  lng :parseFloat(obj.Longitude),
                                  label :'', 
                                  draggable:false,
                                  name:obj.PropertyName
                                })
                            }
                          })

                          // this.markers.push({
                          //     lat : 29.6469187,
                          //     lng :-95.57536900000002,label :'1',draggable:false
                          //   },{
                          //     lat : 30.0976421,
                          //     lng :-95.67798820000002,label :'2',draggable:false
                          //   })
                            try{
                              const bounds: LatLngBounds = new google.maps.LatLngBounds();  
                              if(this.markers.length>1){
                                for (const mm of this.markers) {
                                  bounds.extend(new google.maps.LatLng(mm.lat, mm.lng));
                                }
                                this.bounds= bounds;
                               
                              }
                              else if(this.markers.length==1){
                                let offset = 0.005;
                                for (const mm of this.markers) {
                                  bounds.extend(new google.maps.LatLng(mm.lat, mm.lng));
                                  let center = bounds.getCenter();                            
                                  bounds.extend(new google.maps.LatLng(center.lat() + offset, center.lng() + offset));
                                  bounds.extend(new google.maps.LatLng(center.lat() - offset, center.lng() - offset));
                                }
                                this.bounds= bounds;
                              }
                            }
                            catch{}
                         
                          },(error)=>{ 
                            this.writeException(error,this.objCrsSearchPro);
                            this.isButtondisabled=false;  
                          });
    }
    catch
    {
    console.log('Filter on Location')
    }

  }

  booknow($event :any)
  {  
    let prop=($event);
    
    localStorage["checkIn"]="";
    localStorage["checkOut"]="";
    let url=prop.PropertyType=='Hotel'? 'roomdetails/'+prop.PropertyId : 'crsroomdetails'
    localStorage["PropertyType"]=prop.PropertyType;
    localStorage["PropertyId"]=prop.PropertyId;
    sessionStorage["ConfirmNo"]=0; 
      if(prop.PropertyType=='Hotel'){sessionStorage["crsFlow"]=true}
      else{sessionStorage["crsFlow"]=false}
     
    this.router.navigate([url]);
  }

  search()
  {
    this.isButtondisabled=true;  
    if($('#search_places').val()!="" && this.isautoCompleteSelected)
    {
      this.objCrsSearchPro.SearchKeyword=this.location;
      this.getAllPropertyDetails();
    }
    else if($('#search_places').val()!="")
    {
      this.toastr.info('Please change City or State')
      this.isButtondisabled=false;
    }
    else{
      this.toastr.info('Please enter City or State')
      this.isButtondisabled=false;
    }
   
  }
  autoCompleteCallback1(data: any): any {
    this.isautoCompleteSelected=true;
      let searchKeyword=''
      let address: any =[];   
      try
      {
        data.data.address_components.filter(function(item){
          if(item.types[0]=='locality') // city
          {
          searchKeyword =item.long_name
          address.City = item.long_name;       
          }
          if(item.types[0]=='colloquial_area') // second city
          {
          searchKeyword =item.long_name
          address.City2 =item.long_name;       
          }        
          else if(item.types[0]=='administrative_area_level_1') //state
          {
          searchKeyword=searchKeyword==''?item.long_name : searchKeyword+','+item.long_name  
          address.State = item.long_name;   
          address.Stateshort_name =  item.short_name;   
          }
          else if(item.types[0]=='country') //country
          {
          searchKeyword=searchKeyword==''?item.long_name : searchKeyword+','+item.long_name    
          address.Country = item.long_name 
          address.Countryshort_name =  item.short_name; 
          }
          })

          localStorage["location"]=searchKeyword;
          let locationSearch={
              'searchKeyword':searchKeyword,
              'searchword' : data.data.formatted_address
          }

          localStorage["location"]=JSON.stringify(locationSearch);
          
          localStorage["locationAreaSearch"]=JSON.stringify(
            {
            'City' : address.City, 'City2' : address.City2,
            'State' : address.State,'Stateshort_name':address.Stateshort_name,
            'Country' : address.Country,'Countryshort_name' : address.Countryshort_name
            });
      }
      catch{}
    }

  writeException(error : any ,data :any)
  {
    this.toastr.info("Status : "+error.status+" "+error.statusText)       
    this.AngularException.set(error,"crs-searchresult.component.ts"); 
    this.AngularException.data=JSON.stringify(data);
    this.objCrsService.LogErrorAngToText(this.AngularException);
  }
}
interface marker {
	lat: number;
	lng: number;
	label?: string;
	draggable: boolean;
}
