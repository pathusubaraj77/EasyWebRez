import { Component, OnInit } from '@angular/core';
import{ ServicePath } from '../../../shared/model/service-path'

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {
  ImagePg: any =""
  constructor(public path:ServicePath) { }

  ngOnInit() {
    //alert(this.path.ImagePath+this.path.crsSearchBackgraoundImage)
    // this.prop=JSON.parse(sessionStorage["PropDetails"])
    this.ImagePg=this.path.ImagePath+"/"+this.path.crsSearchBackgraoundImage;
  }
}
