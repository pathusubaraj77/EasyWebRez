import { Injectable } from '@angular/core';
import {Http,Response,RequestOptions,Headers} from '@angular/http';
import {HttpErrorResponse} from '@angular/common/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map'; 
import {ServicePath} from './../../shared/model/service-path'
import 'rxjs/add/operator/catch'
import 'rxjs/add/operator/toPromise';
import 'rxjs/Rx'

@Injectable()
export class CrsService {

  constructor(private http:Http,private servicePath : ServicePath){}  

  getPropertyAddress(body:any) : Observable<any>
  {
    let headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8' });
    let options = new RequestOptions({ headers: headers});

      return this.http.post(this.servicePath.CrsPropertySearch+'GetPropertyAddressSearch',
                      JSON.stringify(body),options)
                      .map((response:Response)=><any>response.json());
  }

  getAllPropertyDetails(body:any) : Observable<any>
  {
    let headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8' });
    let options = new RequestOptions({ headers: headers});

      return this.http.post(this.servicePath.CrsPropertySearch+'GetAllPropertyDetails',
                      JSON.stringify(body),options)
                      .map((response:Response)=><any>response.json())
                      .catch(this.errorHandler)
  }
 

  getPropertyDetails(body:any) : Observable<any>
  {
    let headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8' });
    let options = new RequestOptions({ headers: headers});
    let apiUrl="";
    if(body.directland==true)
    {
      apiUrl=this.servicePath.CrsPropertySearch+'GetPropertyDetailsWithRoomId'
    }
    else
    {
      apiUrl=this.servicePath.CrsPropertySearch+'GetPropertyDetails'
    }
      return this.http.post(apiUrl,JSON.stringify(body),options)
                      .map((response:Response)=><any>response.json());
  }

  getRoomPolicy(PropertyId:any) : Observable<any>
  {
    let headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8' });
    let options = new RequestOptions({ headers: headers});
    let urlQueryString='GetPropertyDetails?PropertyId='+PropertyId

    return this.http.get(this.servicePath.CrsPropertySearch+urlQueryString)                     
                    .map((response:Response)=><any>response.json());
  }

  
  errorHandler(error: HttpErrorResponse)  
  {
    return Observable.throw(error || "Server Error")    
  }
  LogErrorAngToText(body:any) : any
  {
    let headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8' });
    let options = new RequestOptions({ headers: headers});

    this.http.post(this.servicePath.RoomDetails+'LogErrorAngToText',
                      JSON.stringify(body),options).toPromise();                   
  }
}


