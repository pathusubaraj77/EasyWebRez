import { TestBed, inject } from '@angular/core/testing';

import { CrsSearchService } from './crs-search.service';

describe('CrsSearchService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CrsSearchService]
    });
  });

  it('should be created', inject([CrsSearchService], (service: CrsSearchService) => {
    expect(service).toBeTruthy();
  }));
});
