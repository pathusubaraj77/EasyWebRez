import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule }   from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { SharedModule } from './shared/shared.module'
import { RoomsAvailablityModule } from './roomavailablity/roomsavailablity.module'
import { CheckOutModule } from './checkout/checkout.module'
import { ThankyoubookingModule } from './thankyoubooking/thankyoubooking.module'
import { RoomDetailsComponent } from './roomavailablity/component/room-details/room-details.component'
import { NgDatepickerModule } from 'ng2-datepicker';
import { NgxPaginationModule } from 'ngx-pagination'
import { NgbModule } from '@ng-bootstrap/ng-bootstrap'  
import { CrsModule } from './crs/crs.module'
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AgmCoreModule } from '@agm/core';
import { LazyLoadImageModule } from 'ng-lazyload-image';
import {ReadMoreComponent} from '../app/roomavailablity/component/readmore'
@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    CrsModule,
    SharedModule,
    RoomsAvailablityModule,
    CheckOutModule,
    ThankyoubookingModule,
    BrowserModule,
    FormsModule,
    HttpModule,
    NgDatepickerModule,
    NgxPaginationModule,
    BrowserAnimationsModule,
    NgbModule.forRoot(),
    ToastrModule.forRoot(),
    LazyLoadImageModule ,
    RouterModule.forRoot([      
      { path: 'roomdetails/:id', component: RoomDetailsComponent },
    ]),
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyAoL4mXo2Np88EwVjCt7oNQuztAiN7ROeI'
    })  
  ],
  //providers: [{provide: APP_BASE_HREF, useValue: '/EasyWebRez/'}],
  bootstrap: [AppComponent]
})
export class AppModule { }