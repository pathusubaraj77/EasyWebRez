
export class Thankyoubooking 
{
    bookingDetails : any =[]
    invoiceDetails : any=[]
    confirmNo : string 
    objPropDetails: any =[]
    objGuest : any = []
    bookedRooms :string="";
    bookedRoomTypes : string =""
    noOfRooms : number=0
    dynamicText : any =[]
    
    set()
    {
        this.bookingDetails=JSON.parse(sessionStorage["InputProp"]);       
        this.noOfRooms=sessionStorage["NoOfRooms"]  
        this.objPropDetails= JSON.parse(sessionStorage.PropDetails)
        this.objPropDetails.CheckInTime= JSON.parse(sessionStorage.SettingsProp).CheckIn;
        this.objPropDetails.CheckOutTime= JSON.parse(sessionStorage.SettingsProp).CheckOut;

        if(localStorage["dateFormat"]=='dd/mm/yy')
        {
            let df = this.bookingDetails.InDate.split('/');
            let dt = this.bookingDetails.OutDate.split('/');
           
            this.bookingDetails.InDate=df[1]+'/'+df[0]+'/'+df[2]
            this.bookingDetails.OutDate=dt[1]+'/'+dt[0]+'/'+dt[2]        
        }
        
        this.bookedRooms=sessionStorage.Selectedroooms
        this.bookedRoomTypes=sessionStorage.SelectedrooomTypes
    }
}