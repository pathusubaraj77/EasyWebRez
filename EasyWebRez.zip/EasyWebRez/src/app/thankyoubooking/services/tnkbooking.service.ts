import {Injectable} from '@angular/core';
import {Request,Response,RequestOptions,Headers,Http} from '@angular/http'
import {Observable} from 'rxjs/Observable';
import {ServicePath} from './../../shared/model/service-path'
import {HttpErrorResponse} from '@angular/common/http';

@Injectable()
export class TnkbookingService {

  constructor(private http :Http,
             private servicePath:ServicePath) { }


  getGuestDetails(data : any,confirmNo : string) : Observable <any>
  {
    let headers = new Headers({'Content-Type' : 'application/json; charset=utf-8'});
    let options=new RequestOptions({headers :headers});

    return this.http.post(this.servicePath.ThankYouBooing+'GetGuestDetails?confirmNum='+confirmNo,
                    data,options).map((response)=><any>response.json())
                    .catch(this.errorHandler);
  }

  getDynamicText(data : any) : Observable <any>
  {
    let headers = new Headers({'Content-Type' : 'application/json; charset=utf-8'});
    let options=new RequestOptions({headers :headers});

    return this.http.post(this.servicePath.ThankYouBooing+'GetDynamicText',
                    data,options).map((response)=><any>response.json())
                    .catch(this.errorHandler);
  }

  errorHandler(error: HttpErrorResponse)  
  {
    return Observable.throw(error || "Server Error")    
  }
  LogErrorAngToText(body:any) : any
  {
    let headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8' });
    let options = new RequestOptions({ headers: headers});

    this.http.post(this.servicePath.RoomDetails+'LogErrorAngToText',
                      JSON.stringify(body),options).toPromise();                   
  }
}
