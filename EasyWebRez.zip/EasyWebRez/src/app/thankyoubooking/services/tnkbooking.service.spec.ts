import { TestBed, inject } from '@angular/core/testing';

import { TnkbookingService } from './tnkbooking.service';

describe('TnkbookingService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TnkbookingService]
    });
  });

  it('should be created', inject([TnkbookingService], (service: TnkbookingService) => {
    expect(service).toBeTruthy();
  }));
});
