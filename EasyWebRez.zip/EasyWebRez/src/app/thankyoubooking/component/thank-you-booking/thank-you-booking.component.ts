import { Component, OnInit,ViewEncapsulation } from '@angular/core';
import { TnkbookingService }     from './../../services/tnkbooking.service'
import { Thankyoubooking }       from './../../model/thankyoubooking'
import { DataProperty }          from './../../../shared/model/dataProperty'
import { ToastrService }        from 'ngx-toastr';
import { AngularException }    from './../../../shared/model/service-path'

@Component({
  selector      : 'app-thank-you-booking',
  templateUrl   : './thank-you-booking.component.html',
  encapsulation : ViewEncapsulation.None,
  styleUrls     : ['./thank-you-booking.component.css']
})
export class ThankYouBookingComponent implements OnInit {
  PropertyType : string =""
  serviceCharge:any=[];
  Crs : boolean
  serviceChargeStatus: boolean =true
  bookingType : string =''
  constructor(private objTnkbookingService  : TnkbookingService,
              public objThankyoubooking     : Thankyoubooking,
              public AngularException       : AngularException,
              public toastr                 : ToastrService,
              private clsProp               : DataProperty ) {
              this.Crs=localStorage["Crs"]; 
              }
  ngOnInit() 
  {
    try
    {
      this.bookingType=localStorage["bookingType"]=="RoomType"? "Room Type" : "Room Name"
      this.clsProp.PropertyId=localStorage["PropertyId"]
      this.serviceCharge=JSON.parse(sessionStorage["InvoiceDetails"]).HouseKeepingInfo[0];
      if(this.serviceCharge==undefined) this.serviceChargeStatus=false; 
      this.objThankyoubooking.invoiceDetails=JSON.parse(sessionStorage["InvoiceDetails"]);
      this.objThankyoubooking.confirmNo=sessionStorage["ConfirmNo"];
      this.PropertyType=localStorage["PropertyType"]
      this.bookingType=this.PropertyType=="Home"? "Property Name" : this.bookingType;

      this.objThankyoubooking.set();

      this.objTnkbookingService.getGuestDetails(this.clsProp,this.objThankyoubooking.confirmNo)
                              .subscribe((response)=>{
                                this.objThankyoubooking.objGuest=response.GuestProperty; 
                                console.log(this.objThankyoubooking.objGuest)                            
                              },(error)=>{ 
                                this.writeException(error,this.clsProp);
                              })
      this.getDynamicText();
    }
    catch{}      
  }
  getDynamicText()
  {
    this.objTnkbookingService.getDynamicText(this.clsProp)
                          .subscribe((response)=>
                          {
                             this.objThankyoubooking.dynamicText=response
                          },(error)=>{ 
                              this.writeException(error,this.clsProp);
                          })
  }

  writeException(error : any ,data :any)
  {
    this.toastr.info("Status : "+error.status+" "+error.statusText)       
    this.AngularException.set(error,"thankyoubooking.component.ts"); 
    this.AngularException.data=JSON.stringify(data);
    this.objTnkbookingService.LogErrorAngToText(this.AngularException);
  }
  print(): void {
    let printContents, popupWin;
    printContents = document.getElementById('print-section').innerHTML;
    popupWin = window.open('', '_blank', 'top=0,left=0,height=100%,width=auto');
    popupWin.document.open();
    popupWin.document.write(`
      <html>
        <head>
          <title></title>
          <style>
          @import url("https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css");
          .head-thank{
            border-bottom: 3px solid #31b0d5;
            line-height: 38px;
        }
        .contain-full{
            background-color: aliceblue;
            margin-top: 18px;
            margin-bottom: 27px;
            padding: 7px;
        }
        .left{
            border: 1px solid #ccc;
            padding: 12px;
            
        }
        .right{
            border: 1px solid #ccc;
            padding: 12px;
            height: 249px;
        }
        .right1{
            border: 1px solid #ccc;
            padding: 12px;
         
        }
        .bottom-left{
            background-color: aliceblue;
            border-top: 1px solid #cccc;
            /* padding: 3px; */
            margin: -12px;
            padding: 8px 0;
        }
        .bottom-left1{
            padding: 8px 0;
            border-top: 1px solid #cccc;
            /* padding: 3px; */
            margin: -12px;
        }
        .right-bottom{
            background-color: aliceblue;
            border-top: 1px solid #cccc;
            height: 133px;
        }
        .text-auto{
            text-align: center;
        }
        
.
          </style>
        </head>
    <body onload="window.print();window.close()">${printContents}</body>
      </html>`
    );
    popupWin.document.close();
}
}
  