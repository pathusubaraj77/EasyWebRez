import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ThankYouBookingComponent } from './thank-you-booking.component';

describe('ThankYouBookingComponent', () => {
  let component: ThankYouBookingComponent;
  let fixture: ComponentFixture<ThankYouBookingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ThankYouBookingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThankYouBookingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
