import { FormsModule } from '@angular/forms';
import { RouterModule} from '@angular/router';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {ThankYouBookingComponent} from './component/thank-you-booking/thank-you-booking.component'
import {TnkbookingService} from './services/tnkbooking.service'
import {SharedModule} from './../shared/shared.module'
import {DataProperty} from './../shared/model/dataProperty'
import {Thankyoubooking} from './model/thankyoubooking'

@NgModule({
    imports: [ 
        FormsModule,
        BrowserModule,
        SharedModule,
        RouterModule.forRoot([
            {path: 'tnk', component: ThankYouBookingComponent}
            ]) 
    ],
    declarations :[ThankYouBookingComponent],
    providers:[TnkbookingService,Thankyoubooking,DataProperty]
})
export  class ThankyoubookingModule{}
