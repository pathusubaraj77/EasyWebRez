import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import {SearchWidgetComponent} from './../roomavailablity/component/search-widget/search-widget.component'
import {RoomDetailsComponent} from './../roomavailablity/component/room-details/room-details.component'
import {ResultComponent} from './../roomavailablity/component/result/result.component'
import {ReadMoreComponent} from './../roomavailablity/component/readmore'
import {ResultService} from './services/services.result'
import { SearchProp }               from './model/searchProperty'
import {ShopingCartService} from './services/shoping-cart.service'
import { GroupBookingProp }         from './model/GroupBookingProperty'
import { RuleInputProperty }        from './model/ruleInputProperty'
import { DataProperty} from './model/dataProperty'
import { RoomDetails} from './model/roomdetails'
import { ServicePath}   from './../shared/model/service-path'
import { CondoOwnerProperty}  from './model/condoOwnerProperty'
import { Clsrooms}            from './model/Clsrooms'
import { NgDatepickerModule } from 'ng2-datepicker';
import { NgxPaginationModule} from 'ngx-pagination'
import { SharedModule} from './../shared/shared.module'

import { NgbModule } from '@ng-bootstrap/ng-bootstrap'  
import {Result} from './../roomavailablity/model/result'
import { Widget }                   from './model/widget'
import { TempInputProp}       from './model/tempInputProperty'
import {RoomsInputProperty } from './../roomavailablity/model/roomsInputProperty'
import { NgxGalleryModule } from 'ngx-gallery';
import { AgmCoreModule } from '@agm/core';
@NgModule({
    imports: [ 
        FormsModule,
        BrowserModule,
        NgDatepickerModule, 
        NgbModule.forRoot(),
        NgxPaginationModule,
        SharedModule,
        NgxGalleryModule,
        AgmCoreModule.forRoot({
            apiKey: 'AIzaSyAoL4mXo2Np88EwVjCt7oNQuztAiN7ROeI'
        }),
        RouterModule.forRoot([
            //{path: 'EasyWebrez/:id', component: RoomDetailsComponent, pathMatch: 'full'},
            {path :'result', component: ResultComponent},
            //{path: 'widget', component: SearchWidgetComponent}
        ])
    ],
    declarations :[
        SearchWidgetComponent,
        RoomDetailsComponent,
        ResultComponent,
        ReadMoreComponent
    ],
    providers:[
        ResultService,
        ShopingCartService,
        RoomDetails,
        DataProperty,
        Widget,
        Result,
        SearchProp,
        GroupBookingProp,
        RuleInputProperty,
        TempInputProp,
        RoomsInputProperty,
        ServicePath,
        CondoOwnerProperty,
        Clsrooms
    ]
})
export  class RoomsAvailablityModule{}
