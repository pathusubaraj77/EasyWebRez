export class Result
{
   roomLists          : any =[]
   roomTypeNameList   : object =[]; 
   slectedRooms       : object =[]; 
   searchProp         : any;
   noOfAdults         : any = 2;
   roomListId         : any = 0;
   noOfNights         : number =0;
   checkIn            : any;
   checkOut           : any;
   strCheckIn         : any;
   strCheckOut        : any;
   selectedRoomsTotal : any = 0;
   seachInputProp     : any = [];
   objSettingsProp    : any = [];
   imagePath          : string=""
   objModel           : any =[]
   objModelImages     : any =[];
   roomTypeName       : string
   roomName :string
   selectedroomsAdult : string;

   set(imagePath:string,objSettingsProp:any,searchProp:any)
   {
        this.imagePath=imagePath;
        this.objSettingsProp=objSettingsProp;
        this.checkIn=searchProp.CheckIn;
        this.checkOut=searchProp.CheckOut;
        this.noOfNights=searchProp.noOfNights;
        this.strCheckIn=localStorage["checkIn"]
        this.strCheckOut=localStorage["checkOut"]
   }

   set_noOfNights()
   {    
    let diffInMs: number =  Date.parse(this.checkOut) -Date.parse(this.checkIn)
    let diffInHours: number = diffInMs / 1000 / 60 / 60;
    this.noOfNights=(diffInHours/24); 
   }
}