export class Widget
{
    roomTypeNameList  : any =[]
   // clsProp           : any=[]
    roomType          : string = 'All'
    checkIn           : any;
    checkOut          : any;
    noOfAdults        : any =2
    ruleResponce      : any =[]
    noOfNights        : number ;

    constructor(){
       // this.checkIn.setDate(this.checkIn.getDate()+1);
       // this.checkOut.setDate(this.checkIn.getDate()+2);
    }

    set_Date()
    {
        this.checkIn=localStorage.getItem("checkIn");
        this.checkOut=localStorage.getItem("checkOut");
        if(localStorage["dateFormat"]=='dd/mm/yy')
        {
            var df = localStorage["checkIn"].split('/');
            var dt = localStorage["checkOut"].split('/');
           
            this.checkIn=df[1]+'/'+df[0]+'/'+df[2]
            this.checkOut=dt[1]+'/'+dt[0]+'/'+dt[2]
        }
    }

    set_noOfNights()
    {    
     let diffInMs: number =  Date.parse(this.checkOut) -Date.parse(this.checkIn)
     let diffInHours: number = diffInMs / 1000 / 60 / 60;
     this.noOfNights=(diffInHours/24); 
    }
}

