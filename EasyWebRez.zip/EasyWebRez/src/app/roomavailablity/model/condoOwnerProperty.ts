export class CondoOwnerProperty
{
    public  CondoOwnerId : number
    public  CondoOwnerName :string

    set(condoOwnerId : any,condoOwnerName :string){
        this.CondoOwnerId=condoOwnerId
        this.CondoOwnerName=condoOwnerName
    }
}