export class DataProperty
{
    public  PropertyId : number
    public  PMSFolder : string ="PMS"
}

// export class SearchProp
// {  
//     public RoomTypeName :string
//     public CheckIn : any
//     public CheckOut : any
//     public NoOfAdutls :string
// }