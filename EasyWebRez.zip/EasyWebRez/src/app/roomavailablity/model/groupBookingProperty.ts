import {SearchProp} from './../../roomavailablity/model/searchProperty'
export class GroupBookingProp
{
    public  IsGroupBooking : boolean
    public  RoomType : string
    public  InDate : any
    public  OutDate :any
    public  GroupCode : any
    public  RoomListId :any

    set(searchProp:SearchProp)
    {
        this.InDate=searchProp.CheckIn
        this.OutDate=searchProp.CheckOut
        this.RoomType=searchProp.RoomTypeName
    }
}