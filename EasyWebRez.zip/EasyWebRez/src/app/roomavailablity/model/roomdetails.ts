
export class RoomDetails  
{    
   objRoomTypeDetails: any =[];
   objPropDetails    : any =[];
   PropertyName      : any =[];  
   objSettingsProp   : any 
   imagePath         : string=""
   backgroundImage   : string =""
   ruleResponce      : any =[]
   p                 : number = 1;
   objDirection      : any =[];   
   galleryImages     : any =[];
   imageCount        : any =0;
}