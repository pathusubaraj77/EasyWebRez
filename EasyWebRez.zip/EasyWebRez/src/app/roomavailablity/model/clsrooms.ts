import {DataProperty} from './dataProperty'
import {CondoOwnerProperty} from './condoOwnerProperty'

export class Clsrooms
{
    public clsProp :DataProperty
    public roomProp : any
    public condoProp :CondoOwnerProperty

    set(clsProp:DataProperty,roomProp:any,condoProp:CondoOwnerProperty)
    {
       this.clsProp=clsProp;
       this.roomProp=roomProp;
       this.condoProp=condoProp;
    }
}