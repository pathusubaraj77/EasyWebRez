import {SearchProp} from './../../roomavailablity/model/searchProperty'

export class RuleInputProperty
{
    public  FromDate : any
    public  ToDate  : any
    public  RoomType : string
    public  NoofAdult :any
    public  NoofRooms :any
    public  Occupancy :any
    public  IsGroupBooking :boolean
    public  IsCheckPromoOnline : boolean
    public  IsdirectLanding : boolean   
    public  RoomId : any 
    public  StrFromDate :any
    public  StrToDate :any
    set(searchProp: SearchProp,NoofRooms :any,Occupancy :any,
        IsGroupBooking :boolean,IsCheckPromoOnline : boolean)
    {
        this.FromDate=searchProp.CheckIn
        this.ToDate=searchProp.CheckOut
        this.RoomType=searchProp.RoomTypeName
        this.NoofAdult=searchProp.NoOfAdutls
        this.NoofRooms=NoofRooms
        this.Occupancy=searchProp.NoOfAdutls
        this.IsGroupBooking=IsGroupBooking        
        this.IsCheckPromoOnline=IsCheckPromoOnline 
    }
}