export class RoomsInputProperty 
{
    public  InDate  : string
    public  OutDate : string
    public  NofAdults : number
    public  NoofRooms :number
    public  RoomType : string   
    public  IsGroupBooking  :boolean
    public  IsCheckPromoOnline  : boolean
    public  RoomDisplayOrder  : string
    public  RoomListId :any
    public  NofNights : any
    public MaxOccupancy : any
    public sCartId :any
    public PageNo : number

    set(inDate :any ,outDate :any,nofAdults : any,noofRooms: any,roomType : any,
         isGroupBooking :any, isCheckPromoOnline :any, roomDisplayOrder :any, roomListId,NofNights:any)
    {        
        this.InDate=inDate;
        this.OutDate=outDate;
        this.NofNights=NofNights
        this.NofAdults=nofAdults;
        this.NoofRooms=noofRooms;
        this.RoomType=roomType;
        this.IsGroupBooking=isGroupBooking;
        this.IsCheckPromoOnline=isCheckPromoOnline;
        this.RoomDisplayOrder=roomDisplayOrder;
        this.RoomListId=roomListId; 
        this.MaxOccupancy=nofAdults;
        this.sCartId=0
        this.PageNo=1 
    } 
}