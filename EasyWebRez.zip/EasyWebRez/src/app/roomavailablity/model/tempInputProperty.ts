import { startOfDay } from "date-fns";

export class TempInputProp 
{
    public BookingType :string
    public RoomListId :any
    public RoomId :any
    public GidList :any
    public NoofRooms :any
    public RoomName :any
    public RoomType :any
    public RoomImage :any
    public RoomAmount :any
    public Noofhour :any
    public arrival_date :any
    public StartTime :any
    public EndTime :any
    public HourlyType :any

    set(BookingType :string,RoomListId :any,RoomId :any,GidList :any,NoofRooms :any,RoomName :any,RoomType :any,
        RoomImage :any,RoomAmount :any,Noofhour :any,arrival_date :any,StartTime :any,EndTime :any,
        HourlyType :any)
    {
        this.BookingType=BookingType
        this.RoomListId=RoomListId
        this.RoomId=RoomId
        this.GidList=GidList
        this.NoofRooms=NoofRooms
        this.RoomName=RoomName
        this.RoomType=RoomType
        this.RoomImage=RoomImage
        this.RoomAmount=RoomAmount
        this.Noofhour=["''"]
        this.arrival_date=arrival_date
        this.StartTime=StartTime
        this.EndTime=EndTime
        this.HourlyType=HourlyType
    }
}