
export class SearchProp
{  
    public RoomTypeName :string
    public CheckIn : any
    public CheckOut : any
    public NoOfAdutls :string

    set(RoomTypeName :string,CheckIn : any,CheckOut : any,NoOfAdutls :string)
    {
        this.RoomTypeName=RoomTypeName;
        this.CheckIn=CheckIn
        this.CheckOut=CheckOut
        this.NoOfAdutls=NoOfAdutls==undefined ? "2" : NoOfAdutls
    }
}