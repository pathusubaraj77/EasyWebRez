import { Component, Input, ElementRef, OnChanges} from '@angular/core';
//import { OnInit } from '@angular/core/src/metadata/lifecycle_hooks';

@Component({    
    selector: 'read-more',
    template: `
        <div  style="font-size: 14px;" [innerHTML]="currentText">
        </div>
            <a [class.hidden]="hideToggle" *ngIf="isReadmoreLink" style="color:#3aa9eb;cursor:pointer" (click)="toggleView()">Read {{isCollapsed? 'more':'less'}}</a>
    `
})

export class ReadMoreComponent implements OnChanges {
    @Input() text: string;
    @Input() maxLength: number = 100;
    currentText: string;
    hideToggle: boolean = true;
    isReadmoreLink :boolean =false
    plainText : string =''

    public isCollapsed: boolean = true;

    constructor(private elementRef: ElementRef) {

    }
    toggleView() {
        this.isCollapsed = !this.isCollapsed;
        this.determineView();
    }
    determineView() {
        this.plainText =this.text;
        let  plainTextCount = this.plainText.replace(/<[^>]*>/g, '');
        if (plainTextCount.length <= this.maxLength) {
            this.currentText = this.text;
            this.isCollapsed = false;
            this.hideToggle = true;
            return;
        }
        this.hideToggle = false;
        if (this.isCollapsed == true) {
            this.currentText = this.text.substring(0, this.maxLength) + "...";
        } else if(this.isCollapsed == false)  {
            this.currentText = this.text;
        }
        if(plainTextCount.length>300){
            this.isReadmoreLink =true
        }else{
            this.isReadmoreLink =false
        }

    }
    ngOnChanges() {
        this.determineView();       
    }
}

// @Directive({
// selector:"[editorText]"
// })
// class EditorContents implements OnInit {
//     @Input() text: string;
//     editorContents : string
//     ngOnInit() {

//         alert(this.text);
//     }
//  }