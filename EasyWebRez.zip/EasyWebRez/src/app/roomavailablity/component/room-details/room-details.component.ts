import { Component, OnInit, ViewEncapsulation, transition,AfterViewInit } from '@angular/core';
import { Router,ActivatedRoute}   from '@angular/router';
import 'rxjs/add/operator/filter';
import {ResultService,}           from './../../services/services.result'
import {ShopingCartService}       from './../../services/shoping-cart.service'
import {SearchProp}               from './../../model/searchProperty'
import {RoomDetails}              from './../../model/roomdetails'
import {GroupBookingProp}         from './../../model/GroupBookingProperty'
import {RuleInputProperty}        from './../../model/ruleInputProperty'
import {ServicePath,AngularException}              from './../../../shared/model/service-path'
import {DataProperty}             from './../../../shared/model/service-path'
import * as frLocale              from 'date-fns/locale/fr';
import  * as $ from 'jquery';
import { ToastrService} from 'ngx-toastr';
import { empty } from 'rxjs/observable/empty';
import { NgxGalleryModule } from 'ngx-gallery';
import { NgxGalleryOptions, NgxGalleryImage, NgxGalleryAnimation } from 'ngx-gallery';
import { GoogleMapsAPIWrapper, AgmMap, LatLngBounds, LatLngBoundsLiteral} from '@agm/core';
declare var google: any;
import 'hammerjs';
@Component({
  selector      : 'app-room-details',
  encapsulation : ViewEncapsulation.Emulated,
  templateUrl   : './room-details.component.html',
  //templateUrl   : './../../../../../../room-details.component.html',
  styleUrls     : ['./room-details.component.css']
})
export class RoomDetailsComponent implements OnInit,AfterViewInit {
    galleryOptions: NgxGalleryOptions[];
    galleryImages:  NgxGalleryImage[];
    id;
    //mapUrl:string =encodeURI("https://www.google.com/maps/embed/v1/place?q=40.7127837,-74.0059413&amp;key=AIzaSyBCq59RfxcoXmxSQi1zxMm2sy1hcOoSIbU"); 
    propertyGallery =[];
    zoom: number = 8;
    title: string = 'My first AGM project';
    lat: number;//=51.678418;
    lng: number;//=7.809007;
    mapDescription =''
    bounds:any
    editorContents : any = ""

    public markers: any =[] ;
    //  = [
    //   {
    // 	  lat: 51.673858,
    // 	  lng: 7.815982,
    // 	  label: '0',
    // 	  draggable: false
    //   }
    // ]
    
 
  constructor(private router           : Router,
              private servicePath      : ServicePath,
              private ObjResultService : ResultService,
              private searchProp       : SearchProp,
              private objShopingCartService : ShopingCartService,
              private route           : ActivatedRoute,
              private ruleInputProp   : RuleInputProperty,
              private groupInputProp  : GroupBookingProp,
              private clsProp : DataProperty,
              public  objRoomDetails              :RoomDetails,
              private toastr    : ToastrService   ,
              public AngularException :AngularException )
  {    

    this.id = this.route.snapshot.paramMap.get('id');
    localStorage.clear();
    this.route.params.subscribe( params =>{
                            localStorage["PropertyId"]=params.id
    });
    if(sessionStorage["crsFlow"]!=undefined)
    {
      localStorage["crsFlow"]=sessionStorage["crsFlow"]
    }
    else
    { 
      localStorage["crsFlow"]=false 
    }    
    this.clsProp.PropertyId=this.id
    localStorage["PropertyType"]="Hotel";
    sessionStorage["ConfirmNo"]=0
    this.objRoomDetails.imageCount = Array(9).fill(0).map((x,i)=>i);
    localStorage["directLand"]="false";
  }

  clickedMarker(label: string, index: number) {
    //console.log(`clicked the marker: ${label || index}`)
  }
  
  mapClicked($event: MouseEvent) {
    // this.markers.push({
    //   lat: $event.coords.lat,
    //   lng: $event.coords.lng,
    //   draggable: true
    // });   
  }

  mouseOver($event: MouseEvent) {
    //alert("")
  };
  
  
  markerDragEnd(m: marker, $event: MouseEvent) {
    //console.log('dragEnd', m, $event);
  }
  ngAfterViewInit() {
    //alert($('#editorContent').append($('.mov-edit')[0]))
  }

  getBackgroundImage()
  {    
    this.ObjResultService.getHeaderDetails(this.clsProp)
                            .subscribe((message)=>{
                            this.objRoomDetails.backgroundImage=encodeURI(message.BackgroundImage);
                            },(error)=>{ 
                              this.writeException(error,this.clsProp);
                            });
  }
  ngOnInit() 
  {  
    try
    {
      console.clear();
      this.objRoomDetails.imagePath=this.servicePath.ImagePath;
      this.getBackgroundImage(); 
      this.getPhotoGalleryImages();
      this.objRoomDetails.objDirection=[];
      this.getDirectionInfo();
//      this.getEditorContents();
      this.getCMSeditorContents();
      //Getting bottom showing room names
      this.ObjResultService.getPropertyDetails(this.clsProp)
                            .subscribe((message)=>
                            {
                            this.objRoomDetails.objPropDetails=message;
                            sessionStorage.setItem("PropDetails", JSON.stringify(message))
                            this.objRoomDetails.PropertyName=this.objRoomDetails.objPropDetails.PropertyName; 
                            localStorage["PropertyName"]=this.objRoomDetails.PropertyName;
                            },(error)=>{ 
                              this.writeException(error,this.clsProp);
                            }); 
  
      sessionStorage["RoomListId"]=sessionStorage["RoomListId"]==undefined ? "0" : sessionStorage["RoomListId"]
      sessionStorage["cartListId"]=sessionStorage["cartListId"]==undefined ? "0" : sessionStorage["cartListId"]
  
      if(sessionStorage["RoomListId"]!="0")
      {
        this.ObjResultService.removeSelectedRooms(this.clsProp,0)
                            .subscribe((response)=>{                            
                            },(error)=>{ 
                              this.writeException(error,this.clsProp);
                            });
      }  
  
      if(sessionStorage["cartListId"]!="0")
      {            
        let body =this.clsProp
        let sCartId = sessionStorage["cartListId"]
        this.objShopingCartService.removeCartList(body,sCartId,0)
                            .subscribe((response)=>{                          
                            },(error)=>{ 
                              this.writeException(error,body);
                            });
      }   
  
      this.ObjResultService.getRoomTypeDetails(this.clsProp)
                            .subscribe((message)=>{
                              
                            this.objRoomDetails.objRoomTypeDetails=message;
                            this.objRoomDetails.objRoomTypeDetails=this.objRoomDetails.objRoomTypeDetails.filter(data => data.RoomType!="Meeting Room"); 
                            },(error)=>{ 
                              this.writeException(error,this.clsProp);
                            });
  
      this.ObjResultService.getPropertySettingDetails(this.clsProp)
                            .subscribe((message)=>{this.objRoomDetails.objSettingsProp=message; 
                             sessionStorage["SettingsProp"]=JSON.stringify(this.objRoomDetails.objSettingsProp);
                             localStorage["dateFormat"]=JSON.parse(sessionStorage["SettingsProp"]).DateFormate;
                            },(error)=>{ 
                              this.writeException(error,this.clsProp);
                            });
                            this.galleryOptions = [
                              {
                                  width: '100%',
                                  height: '500px',
                                  thumbnailsColumns: 4,
                                  imageAnimation: NgxGalleryAnimation.Slide
                              },
                              // max-width 800
                              {
                                  breakpoint: 800,
                                  width: '100%',
                                  height: '600px',
                                  imagePercent: 80,
                                  thumbnailsPercent: 20,
                                  thumbnailsMargin: 20,
                                  thumbnailMargin: 20
                              },
                              // max-width 400
                              {
                                  breakpoint: 400,
                                  preview: false
                              }
                          ];                      
    }
    catch{}    

  }

 

  getDirectionInfo()
  {   
    //this.bounds =[];
    this.ObjResultService.getDirectionInfo(this.clsProp)
                            .subscribe((response)=>
                            {
                              try {
                                this.objRoomDetails.objDirection=response;
                                // this.mapUrl="https://www.google.com/maps/embed/v1/place?q="
                                // +this.objRoomDetails.objDirection[0].Latitude
                                // +",-"+this.objRoomDetails.objDirection[0].Longtitude
                                // +"&amp;key=AIzaSyBCq59RfxcoXmxSQi1zxMm2sy1hcOoSIbU";
                                this.mapDescription=this.objRoomDetails.objDirection[0].Description;
                                this.markers.push(
                                  {
                                    lat:  this.objRoomDetails.objDirection[0].Latitude,
                                    lng: this.objRoomDetails.objDirection[0].Longtitude,
                                    label: '',
                                    draggable: false
                                  })
                                  const bounds: LatLngBounds = new google.maps.LatLngBounds();
                                  let offset = 0.0001;
                                  for (const mm of this.markers) {
                                    bounds.extend(new google.maps.LatLng(mm.lat, mm.lng));
                                    let center = bounds.getCenter();                            
                                    bounds.extend(new google.maps.LatLng(center.lat() + offset, center.lng() + offset));
                                    bounds.extend(new google.maps.LatLng(center.lat() - offset, center.lng() - offset));
                                  }
                                  this.bounds= bounds;
                              }
                              catch{ }

                          },(error)=>{ 
                            this.writeException(error,this.clsProp);
                          });
  }
  getCMSeditorContents()
  {
    this.ObjResultService.getCMSeditorContents(this.clsProp)
                        .subscribe((message)=>
                        {      
                          this.editorContents = message;
                            //$('#editorHidden').append(this.editorContents.Homepage)
                            $('#editorContent').append(this.editorContents.Homepage)
                        },(error)=>{ 
                          this.writeException(error,this.clsProp);
                        });
  }
  toggle()
  {
      $('#sidebar, #content').toggleClass('active');
      $('.collapse.in').toggleClass('in');
      $('a[aria-expanded=true]').attr('aria-expanded', 'false');
  }

  getPhotoGalleryImages()
  {
    this.ObjResultService.getPhotoGalleryImages(this.clsProp)
                      .subscribe((response)=>{                 
                       this.objRoomDetails.galleryImages=response 
                       this.propertyGallery=[
                        this.checkType(this.objRoomDetails.galleryImages.image1),
                        this.checkType(this.objRoomDetails.galleryImages.image2),
                        this.checkType(this.objRoomDetails.galleryImages.image3),
                        this.checkType(this.objRoomDetails.galleryImages.image4),
                        this.checkType(this.objRoomDetails.galleryImages.image5),
                        this.checkType(this.objRoomDetails.galleryImages.image6),
                        this.checkType(this.objRoomDetails.galleryImages.image7),
                        this.checkType(this.objRoomDetails.galleryImages.image8),
                        this.checkType(this.objRoomDetails.galleryImages.image9)                       
                       ]

                    this.propertyGallery=this.propertyGallery.filter(word => word.length > 0);
                    //console.log(this.propertyGallery)
                    sessionStorage["gallerySessProp"]=this.propertyGallery;
                    this.galleryImages = this.propertyGallery.map(value => {
                                          return { 
                                            small : value,
                                            medium :  value,
                                            big :  value };
                    });

                       //console.log(response)
                       },(error)=>{ 
                        this.writeException(error,this.clsProp);
                       });
  }

  checkType(imageName : any) : string
  {
    if(imageName!="" && imageName!=undefined)
    {
      return this.servicePath.ImagePath+'/'+imageName;
    }
    else
    {
      return '';//this.servicePath.ImagePath+'/'+this.servicePath.noImageCart;
    }
  }

  getEditorContents()
  {
    let objEditorReq={
      element : 'BodyContent',
      pageName :'Index',
      PropertyId :this.clsProp.PropertyId
    }
    
    this.ObjResultService.getEditorContents(objEditorReq)
                      .subscribe((message)=>
                      {
                        try
                        {
                          this.editorContents=message;
                          if(this.editorContents!=""){
                            // $('#editorHidden').append(message)
                            // $('#editorContent').append($('.mov-edit')[0])
                          }
                        }
                        catch{
                          // $('#editorContent').append($('.mov-edit')[0])
                        }
                      },(error)=>{ 
                        this.writeException(error,this.clsProp);
                      }); 
  }

writeException(error : any ,data :any)
  {
    this.toastr.info("Status : "+error.status+" "+error.statusText)       
    this.AngularException.set(error,"room-details.component.ts"); 
    this.AngularException.data=JSON.stringify(data);
    this.ObjResultService.LogErrorAngToText(this.AngularException);
  }
}

interface marker {
	lat: number;
	lng: number;
	label?: string;
	draggable: boolean;
}
