import { Component, OnInit,ViewEncapsulation} from '@angular/core';
import { ResultService}       from './../../services/services.result'
import { ServicePath,AngularException}         from './../../../shared/model/service-path'
import { CondoOwnerProperty}  from './../../model/condoOwnerProperty'
import { DataProperty}        from './../../model/dataProperty'
import { Clsrooms}            from './../../model/Clsrooms'
import { TempInputProp}       from './../../model/tempInputProperty'
import { Result}              from './../../model/result'
import { RoomsInputProperty}  from './../../model/roomsInputProperty'
import { Router, NavigationEnd } from '@angular/router'
import { SearchProp }               from './../../model/searchProperty'
import { GroupBookingProp }         from './../../model/GroupBookingProperty'
import { RuleInputProperty }        from './../../model/ruleInputProperty'
import { Widget }                   from './../../model/widget'
import { ToastrService}             from 'ngx-toastr';
import * as frLocale                from 'date-fns/locale/en';
import {ReadMoreComponent} from '../readmore'
import { NgxGalleryOptions, NgxGalleryImage, NgxGalleryAnimation } from 'ngx-gallery'
@Component({
  selector      : 'app-result',
  templateUrl   : './result.component.html',
  encapsulation : ViewEncapsulation.Emulated,
  styleUrls     : ['./result.component.css'],
})

export class ResultComponent implements OnInit  
{
  clearStatus:boolean=false;
  isButtondisabled = false
  isSearchButtondisabled=false  
  noroomsAvailable : boolean 
  isloader : boolean
  bookingType : string =''
  roomImages: any ="";
  galleryOptions: NgxGalleryOptions[];
  roomImagesList:  NgxGalleryImage[];
  constructor(private objResultService : ResultService,
              private servicePath      : ServicePath,
              public  inputProp        : RoomsInputProperty,
              private condoProp        : CondoOwnerProperty,
              private dataProp         : DataProperty,
              private clsrooms         : Clsrooms,
              private tempInputProp    : TempInputProp,
              public objResult         : Result ,
              private router           : Router,
              private searchProp       : SearchProp,
              private ruleInputProp    : RuleInputProperty,
              private groupInputProp   : GroupBookingProp,
              public objWidget         : Widget,
              private toastr           : ToastrService   ,
              public AngularException  : AngularException,         
            ){ 
              this.noroomsAvailable=false
            }              

  //Onload function calls
  ngOnInit() 
  {
    try
        { 
        this.dataProp.PropertyId=localStorage["PropertyId"];
        sessionStorage["NoOfRooms"]=0;
        this.bookingType=localStorage["bookingType"]=="RoomType"? "Room Type" : "Room Name"
        this.isloader=true;
        this.objResult.set(this.servicePath.ImagePath,JSON.parse(sessionStorage["SettingsProp"]),JSON.parse(localStorage.getItem("SearchProp")))
        this.objResult.noOfAdults=JSON.parse(localStorage.getItem("SearchProp")).NoOfAdutls;
        this.objResult.roomTypeName=JSON.parse(localStorage.getItem("SearchProp")).RoomTypeName;
        this.objResult.set_noOfNights()


        this.getRoomList("Init");

        this.objResultService.getRoomTypeList(this.dataProp)
                              .subscribe((message)=>
                              {
                                this.objResult.roomTypeNameList=message;                              
                              },(error)=>{ 
                                this.writeException(error,this.dataProp);
                              }); 

        this.inputProp.set(this.objResult.checkIn, this.objResult.checkOut,this.objResult.noOfAdults,
                1,this.objResult.roomTypeName,false,false,'roomno',sessionStorage["RoomListId"],this.objResult.noOfNights)

        this.condoProp.set(0,'')    

        this.clsrooms.set(this.dataProp,this.inputProp,this.condoProp)

        //Calling ResultService for Available room Details         
        this.objResultService.getRoomsResult(this.clsrooms)
                              .subscribe((message)=>                             
                              {
                                this.isloader=false
                                this.objResult.roomLists=message;
                                //console.log(message)
                                if(message.length==0) {this.noroomsAvailable=true}
                                else{this.noroomsAvailable=false}                             
                              },(error)=>{ 
                                this.writeException(error,this.clsrooms);
                              }); 

        this.getRoomtypeList();
        this.router.events.subscribe((evt) => {
          if (!(evt instanceof NavigationEnd)) {
              return;
          }
          window.scrollTo(0, 0)
        });

        this.galleryOptions = [
          {
              width: '100%',
              height: '500px',
              thumbnailsColumns: 4,
              imageAnimation: NgxGalleryAnimation.Slide
          },
          {
              breakpoint: 800,
              width: '100%',
              height: '600px',
              imagePercent: 80,
              thumbnailsPercent: 20,
              thumbnailsMargin: 20,
              thumbnailMargin: 20
          },
          // max-width 
          {
              breakpoint: 400,
              preview: false
          }
      ];
    }
    catch {}
  }
            
  booknow( objRoom : any,objRate :any)
  {
    this.isButtondisabled=true;
    let room = objRoom;
    let rate = objRate;
    let unitTotal = 0;
    this.objResult.seachInputProp=JSON.parse(sessionStorage["InputProp"]);
    this.objResult.selectedroomsAdult=this.objResult.seachInputProp.NofAdults;
    
    // let unitTotal=room.RateInfo[0].BaseAmount+room.RateInfo[0].Extrapersoncharge+room.RateInfo[0].Weekendcharge;
    // this.tempInputProp.set('RoomName',sessionStorage["RoomListId"],[room.RoomId],[room.RateInfo[0].Gid],1,[room.RoomName],
    //                         room.RoomType,[room.RoomImage],[unitTotal],[''],[''],[''],[''],[''])

    // for multiple rate changes for Room Name
    if(this.bookingType=='Room Name'){
      unitTotal=rate.BaseAmount+rate.Extrapersoncharge+rate.Weekendcharge;
      this.tempInputProp.set('RoomName',sessionStorage["RoomListId"],[room.RoomId],[rate.Gid],1,[room.RoomName],
                              room.RoomType,[''],[unitTotal],[''],[''],[''],[''],[''])
    }
    else
    {
      unitTotal=rate.BaseTotal;
      this.tempInputProp.set('RoomName',sessionStorage["RoomListId"],[room.RoomId],[rate.Gid_List[0]],1,[room.RoomName],
                              room.RoomType,[''],[unitTotal],[''],[''],[''],[''],[''])
    }
    
    //this.objResult.roomLists
    let body=JSON.stringify({clsProp :this.dataProp,tempProp: this.tempInputProp});

    //Adding selected rooms in temp rooms  
    this.objResultService.addToRoomList(body)
                         .subscribe((response)=>{
                          this.objResult.roomListId=response
                          sessionStorage.setItem("RoomListId",this.objResult.roomListId) 
                          this.clsrooms.roomProp.RoomListId=this.objResult.roomListId;
                                    //Reload availablity
                                    this.clearStatus=false
                                    this.objResultService.getRoomsResult(this.clsrooms)
                                    .subscribe((message)=>
                                    {
                                    this.objResult.roomLists=message;            
                                    if(message.length==0) {this.noroomsAvailable=true}
                                    else{this.noroomsAvailable=false}
                                    this.isButtondisabled=false;
                                    },(error)=>{ 
                                      this.writeException(error,this.clsrooms);
                                    });  
                                    
                                    this.getRoomList("Init");
                                  },(error)=>{ 
                                    this.writeException(error,JSON.parse(body));
                                  }); 
    //selected rooms function end
  } 

  getRoomList(fnInput : string)
  {
    this.objResultService.getRoomList(this.dataProp)
                 .subscribe((response)=>{this.objResult.slectedRooms=response                 
                  sessionStorage["Selectedroooms"] =response.map((obj) => obj.RoomName).toString();
                  sessionStorage["SelectedrooomTypes"] =response.map((obj) => obj.RoomType).toString(); 
                  sessionStorage["NoOfRooms"]  =   response.length;  
                  let roomTotal=0;   
                  response.forEach(function(val,index)
                  {
                    roomTotal=roomTotal+val.RoomTotal;
                  });
                  this.objResult.selectedRoomsTotal=roomTotal;
                if(fnInput!="Init")
                {
                  this.objResultService.getRoomsResult(this.clsrooms)
                  .subscribe((message)=>{this.objResult.roomLists=message; 
                    if(message.length==0) {this.noroomsAvailable=true}
                    else{this.noroomsAvailable=false}
                    },(error)=>{ 
                      this.writeException(error,this.clsrooms);
                    });  
                }

    },(error)=>{ 
      this.writeException(error,this.dataProp);
    }); 
  }
  
  //Getting available rooms 
  searchAvailablity()
  { 
    //let dataStatus=($event);
    this.isSearchButtondisabled=true
    this.objResult.selectedRoomsTotal=0;
    
    this.objResult.set(this.servicePath.ImagePath,JSON.parse(sessionStorage["SettingsProp"]),JSON.parse(localStorage.getItem("SearchProp")))    
    this.objResult.checkIn=localStorage["checkIn"]
    this.objResult.checkOut=localStorage["checkOut"]
    if(localStorage["dateFormat"]=='dd/mm/yy')
    {
        var df = localStorage["checkIn"].split('/');
        var dt = localStorage["checkOut"].split('/');
       
        this.objResult.checkIn=df[1]+'/'+df[0]+'/'+df[2]
        this.objResult.checkOut=dt[1]+'/'+dt[0]+'/'+dt[2]
    }
    this.objResult.set_noOfNights()
    if(this.objResult.checkIn==this.objResult.checkOut)
    {
      this.toastr.warning("Sorry please change checkout date");
      this.isSearchButtondisabled=false;
      return false;
    }

    this.inputProp.set(this.objResult.checkIn,this.objResult.checkOut,this.objResult.noOfAdults,
                1,this.objResult.roomTypeName,false,false,'roomno',sessionStorage["RoomListId"],
                this.objResult.noOfNights)

    sessionStorage["InputProp"]=JSON.stringify(this.inputProp);
    sessionStorage["PropertyId"]=localStorage["PropertyId"];    

    this.condoProp.set(0,'')
    this.clsrooms.set(this.dataProp,this.inputProp,this.condoProp)
    if(this.clearStatus){
     // this.clearSelectedRooms(0);
      if(sessionStorage.RoomListId!="0")
      {
          this.dataProp.PropertyId=localStorage["PropertyId"]
          this.dataProp.PMSFolder='PMS'  
          this.objResultService.removeSelectedRooms(this.dataProp,0)
                                .subscribe((response)=>{
                                  this.getRoomList("");
                                },(error)=>{ 
                                  this.writeException(error,this.dataProp);
                                }); 
      }  
    }
    this.checkReservationRule();
  }  
  //Removing selected rooms from booking
  clearSelectedRooms($event:any)
  {
    let RoomId=($event)
    if(sessionStorage.RoomListId!="0")
    {
        this.dataProp.PropertyId=localStorage["PropertyId"]
        this.dataProp.PMSFolder='PMS'

        this.objResultService.removeSelectedRooms(this.dataProp,RoomId)
                              .subscribe((response)=>{
                                this.getRoomList("");
                              },(error)=>{ 
                                this.writeException(error,this.dataProp);
                              }); 
    }  
  }
  modelUpdate($event : any)
  {
    this.objResult.objModel=($event);
    this.objResult.objModelImages=this.objResult.objModel.RoomImage.split(',');   
    this.objResult.objModelImages.pop()  
    
    this.roomImages=this.objResult.objModel.RoomImage.split(','); 
    this.roomImages=this.roomImages.filter(word => word.length > 0);
    this.roomImagesList = this.roomImages.map(value => {
                          return { 
                            small : this.objResult.imagePath+'/'+value,
                            medium :  this.objResult.imagePath+'/'+value,
                            big :  this.objResult.imagePath+'/'+value };
    });
  }
  getRoomtypeList() : any
  {
    //Calling ResultService for RoomType Name List Details            
    this.objResultService.getRoomTypeList(this.dataProp)
                         .subscribe((message)=>{this.objWidget.roomTypeNameList=message;
                         },(error)=>{ 
                          this.writeException(error,this.dataProp);
                        }); 
  } 

  checkReservationRule()
  {   
    this.objWidget.set_Date();

    this.objWidget.noOfAdults=this.objResult.noOfAdults;

    this.searchProp.set(this.objResult.roomTypeName,this.objWidget.checkIn,
    this.objWidget.checkOut,this.objWidget.noOfAdults)

    localStorage.setItem("SearchProp", JSON.stringify(this.searchProp));    
    this.ruleInputProp.set(this.searchProp,1,1,false,false);
    this.groupInputProp.set(this.searchProp);

    let body={"clsProp":this.dataProp,"inputProp" :this.ruleInputProp,"grouprop" : this.groupInputProp};
         
    this.objResultService.GetNormalRuleList(body)
        .subscribe((message)=>
        {
            this.objWidget.ruleResponce=message;      
            if(message=="")
            {
              this.objResultService.GetReservationRuleList(body)
              .subscribe((message)=>
              {
              this.objWidget.ruleResponce=message;
              if(message.search("Error")==-1)
              {
                this.objResultService.getRoomsResult(this.clsrooms)
                    .subscribe((message)=>{this.objResult.roomLists=message;
                      if(message.length==0) {this.noroomsAvailable=true}
                      else{this.noroomsAvailable=false}
                      this.isSearchButtondisabled=false
                      },(error)=>{ 
                        this.writeException(error,this.clsrooms);
                      });
              }
              else
              {
                this.toastr.warning(message.split("=")[1])
                this.isSearchButtondisabled=false
                this.objResult.roomLists=[];
              }
              },(error)=>{ 
                this.writeException(error,body);
              });
            }
            if(message.search("Error")!=-1)
            {
              this.toastr.warning(message.split("=")[1])
              this.isSearchButtondisabled=false
              this.objResult.roomLists=[];
            }
          },(error)=>{ 
            this.writeException(error,body);
          });
  }

  compleBooking()
  {
    if(sessionStorage["NoOfRooms"]!=0)
    {
      this.inputProp.NoofRooms=sessionStorage["NoOfRooms"];
      sessionStorage["InputProp"]=JSON.stringify(this.inputProp);
      this.router.navigate(['/reg']);
    }
    else{
      this.toastr.warning('Please select atleast one room');
    }
  }

  writeException(error : any ,data :any)
  {
    this.toastr.info("Status : "+error.status+" "+error.statusText)       
    this.AngularException.set(error,"result.component.ts"); 
    this.AngularException.data=JSON.stringify(data);
    this.objResultService.LogErrorAngToText(this.AngularException);
  }
}

