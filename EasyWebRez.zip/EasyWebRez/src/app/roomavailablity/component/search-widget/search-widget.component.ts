import { Component, OnInit, ViewEncapsulation  }  from '@angular/core';
import { Router }  from '@angular/router';
import { SearchProp }               from './../../model/searchProperty'
import { ResultService }            from './../../services/services.result'
import { GroupBookingProp }         from './../../model/GroupBookingProperty'
import { RuleInputProperty }        from './../../model/ruleInputProperty'
import { Widget }                   from './../../model/widget'
import { DataProperty}              from '../../model/dataProperty'
import { DatepickerOptions}         from 'ng2-datepicker'
import * as frLocale                from 'date-fns/locale/en';
import { ToastrService}             from 'ngx-toastr';
import { RoomsInputProperty}        from './../../model/roomsInputProperty'
import {AngularException}           from './../../../shared/model/service-path'

@Component({
  selector      : 'app-search-widget',
  encapsulation : ViewEncapsulation.Emulated,
  templateUrl   : './search-widget.component.html',
  styleUrls     : ['./search-widget.component.css']
 })
export class SearchWidgetComponent implements OnInit {

  isButtondisabled=false;
  constructor(private objResultService : ResultService,
    private searchProp     : SearchProp,
    private router         : Router,
    private ruleInputProp  : RuleInputProperty,
    private groupInputProp : GroupBookingProp,
    public objWidget       : Widget,
    private clsProp        : DataProperty,
    private toastr         : ToastrService,
    public  inputProp      : RoomsInputProperty,
    public AngularException :AngularException
  ) { }

  ngOnInit() 
  {
    try{
      this.clsProp.PropertyId=localStorage["PropertyId"] 
      this.getRoomtypeList();
    }
    catch{}     
  }
  getRoomtypeList() : any
  {
    //Calling ResultService for RoomType Name List Details            
    this.objResultService.getRoomTypeList(this.clsProp)
                         .subscribe((message)=>
                         {this.objWidget.roomTypeNameList=message;
                         },(error)=>{ 
                          this.writeException(error,this.clsProp);
                        });   
  }
 
  searchAvailablity($event : any)
  { 
    this.isButtondisabled=true  
    this.objWidget.set_Date();
    
    if(this.objWidget.checkIn==this.objWidget.checkOut){
      this.toastr.warning("Sorry please change checkout date");
      this.isButtondisabled=false;
      return false;
    }
    this.searchProp.set(this.objWidget.roomType,this.objWidget.checkIn,
    this.objWidget.checkOut,this.objWidget.noOfAdults)

    localStorage.setItem("SearchProp", JSON.stringify(this.searchProp));

    this.objWidget.set_noOfNights()
    //localStorage["checkIn"],localStorage["checkOut"]
    this.inputProp.set(this.objWidget.checkIn,this.objWidget.checkOut,this.objWidget.noOfAdults,
                0,this.objWidget.roomType,false,false,'roomno',sessionStorage["RoomListId"],
                this.objWidget.noOfNights)

    sessionStorage["InputProp"]=JSON.stringify(this.inputProp);
    

    this.ruleInputProp.set(this.searchProp,1,1,false,false);
    this.groupInputProp.set(this.searchProp);
    let body={"clsProp":this.clsProp,"inputProp" :this.ruleInputProp,"grouprop" : this.groupInputProp};
         
    this.objResultService.GetNormalRuleList(body)
        .subscribe((message)=>{this.objWidget.ruleResponce=message;      
            if(message=="")
            {
              this.objResultService.GetReservationRuleList(body)
              .subscribe((message)=>{this.objWidget.ruleResponce=message;
              if(message.search("Error")==-1)
              {
                this.router.navigate(['/result']);
              }
              else
              {
                this.toastr.warning(message.split("=")[1])
                this.isButtondisabled=false 
              }
            },(error)=>{ 
              this.writeException(error,body);
            });
            }
            if(message.search("Error")!=-1)
            {
              this.toastr.warning(message.split("=")[1])
              this.isButtondisabled=false 
            }
          },(error)=>{ 
            this.writeException(error,body);
          });
  }
  clearSelectedRooms($event : any){}  

  writeException(error : any ,data :any)
  {
    this.toastr.info("Status : "+error.status+" "+error.statusText)       
    this.AngularException.set(error,"search-widget.component.ts");
    this.AngularException.data=JSON.stringify(data);
    this.objResultService.LogErrorAngToText(this.AngularException);
  }
}
