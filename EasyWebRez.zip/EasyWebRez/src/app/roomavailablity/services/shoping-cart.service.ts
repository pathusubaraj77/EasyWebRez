import {Injectable} from '@angular/core';
import {Request,Response,RequestOptions,Headers,Http} from '@angular/http'
import {HttpErrorResponse} from '@angular/common/http';
import {Observable} from 'rxjs/Observable';
import {ServicePath} from './../../shared/model/service-path'

@Injectable()
export class ShopingCartService
{
    constructor(
        private http:Http,
        private servicePath : ServicePath){}  

    getAvailableCartList(objData: any) : Observable<any>
    {
        let header =new Headers({'Content-Type' : 'application/json; charset=utf-8'});
        let options=new RequestOptions({headers :header});

        return this.http.post(this.servicePath.ShoppingCart+'GetAvailableCartDetails',
                         objData,options)
                        .map((response)=><any>response.json())
                        .catch(this.errorHandler);

    }

    getInvoiceDetails(objData: any) : Observable<any>
    {
        let header =new Headers({'Content-Type' : 'application/json; charset=utf-8'});
        let options=new RequestOptions({headers :header});

        return this.http.post(this.servicePath.CheckOut+'GetRoomInvoiceSummary',
                         objData,options)
                        .map((response)=><any>response.json())
                        .catch(this.errorHandler);

    }

    addCartDetails(data :any) : Promise<any> 
    {
        let headers = new Headers({'Content-Type' : 'application/json; charset=utf-8'});
        let options=new RequestOptions({headers :headers});

        return this.http.post(this.servicePath.ShoppingCart+'AddToCartList',
                        data,options)
                        .toPromise();
    }



    getselectedCartList(objData: any) : Observable<any>
    {
        let header =new Headers({'Content-Type' : 'application/json; charset=utf-8'});
        let options=new RequestOptions({headers :header});

        return this.http.post(this.servicePath.ShoppingCart+'GetTempCartDetails',
                         objData,options)
                        .map((response)=><any>response.json())
                        .catch(this.errorHandler);

    }

    removeCartList(objData: any,sCartId: any,AccId : any) :  Observable<any>
    {
        let header =new Headers({'Content-Type' : 'application/json; charset=utf-8'});
        let options=new RequestOptions({headers :header});
        let queryString='RemoveCartList?sCartId='+sCartId+'&AccId='+AccId
        
        return this.http.post(this.servicePath.ShoppingCart+queryString,
                         objData,options)
                         .map((response)=><any>response.json())
                         .catch(this.errorHandler);
    }

    errorHandler(error: HttpErrorResponse)  
    {
      return Observable.throw(error || "Server Error")    
    }
    LogErrorAngToText(body:any) : any
    {
      let headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8' });
      let options = new RequestOptions({ headers: headers});
  
      this.http.post(this.servicePath.RoomDetails+'LogErrorAngToText',
                        JSON.stringify(body),options).toPromise();                   
    }
}
