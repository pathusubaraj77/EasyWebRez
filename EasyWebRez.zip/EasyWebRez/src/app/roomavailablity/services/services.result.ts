import {Injectable} from '@angular/core';
import {Http,Response,RequestOptions,Headers} from '@angular/http';
import {HttpErrorResponse} from '@angular/common/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import {ServicePath} from './../../shared/model/service-path'

@Injectable()
export class ResultService 
{
      constructor(private http:Http,private servicePath : ServicePath){}  

    //Get available rooms
    getRoomsResult(body:any) : Observable<any> 
    {
      let headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8' });
      let options = new RequestOptions({ headers: headers});
      let apiUrl=localStorage["bookingType"]=="RoomName"? this.servicePath.SearchResult+'GetRoomAdding' :this.servicePath.SearchResult+'GetRoomAdding2'
      return this.http.post(apiUrl,JSON.stringify(body),options)
                      .map((response:Response)=><any>response.json())
                      .catch(this.errorHandler);
    }
    //Get roomtype dropdown list
    getRoomTypeList(objDataProp : object) : Observable<object> 
    {
      let headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8' });
      let options = new RequestOptions({ headers: headers});

      return this.http.post(this.servicePath.RoomDetails+'RoomTypes',
                      JSON.stringify(objDataProp),options)
                      .map((response:Response)=><object>response.json())
                      .catch(this.errorHandler);
    }

    //Get all rooms showing in bottom of roomdetails page
    getRoomTypeDetails(objDataProp : object) :Observable<object> 
    {
      let headers= new Headers({'Content-Type' : 'application/json; charset=utf-8'});
      let myParams ="?roomType=all&roomDisplayOrder=roomno"
      let options=new RequestOptions({headers : headers}); 
      
      return this.http.post(this.servicePath.RoomDetails+'GetRoomDetails'+myParams,
                      JSON.stringify(objDataProp),options)
                      .map((responce:Response) => <object>responce.json())
                      .catch(this.errorHandler);
    }

    getCustomHeaderHtml(propId : string) { 
      let url=this.servicePath.customHeaderPath+"header_"+propId+".html"     
      return this.http.get(url);
    }

    //Get footer and property details
    getPropertyDetails(objDatarop : object) :Observable<object> 
    {
      let headers= new Headers({'Content-Type' : 'application/json; charset=utf-8'});   
      let options=new RequestOptions({
          headers : headers,
        });       
      return this.http.post(this.servicePath.RoomDetails+'GetHotelDetails',
                      JSON.stringify(objDatarop),options)
                      .map((responce:Response) => <object>responce.json())
                      .catch(this.errorHandler);
    }

     //Get footer and property details
     getPropertySettingDetails(objDatarop : object) :Observable<object> 
     {
       let headers= new Headers({'Content-Type' : 'application/json; charset=utf-8'});   
       let options=new RequestOptions({
           headers : headers,
         });       
       return this.http.post(this.servicePath.RoomDetails+'GetOptionSettings',
                       JSON.stringify(objDatarop),options)
                       .map((responce:Response) => <object>responce.json())
                       .catch(this.errorHandler);
     }

     GetPropertySettings(objDatarop : object) :Observable<object> 
     {
       let headers= new Headers({'Content-Type' : 'application/json; charset=utf-8'});   
       let options=new RequestOptions({
           headers : headers,
         });       
       return this.http.post(this.servicePath.RoomDetails+'GetPropertySettings',
                       JSON.stringify(objDatarop),options)
                       .map((responce:Response) => <object>responce.json())
                       .catch(this.errorHandler);
     }

     GetBlockRoomDetails(body : any) :Observable<any> 
     {
       let headers= new Headers({'Content-Type' : 'application/json; charset=utf-8'});   
       let options=new RequestOptions({
           headers : headers,
         });       
       return this.http.post(this.servicePath.CrsPropertySearch+'GetBlockRoomDetails',
                       JSON.stringify(body),options)
                       .map((responce:Response) => <object>responce.json())
                       .catch(this.errorHandler);
     }

    //  async getPropertySettingDetailsPromises(objDatarop : object) :Promise<any> 
    //  {
    //    let headers= new Headers({'Content-Type' : 'application/json; charset=utf-8'});   
    //    let options=new RequestOptions({
    //        headers : headers,
    //      });       
    //     let result = await this.http.post(this.servicePath.RoomDetails+'GetOptionSettings',
    //                    JSON.stringify(objDatarop),options).toPromise();
    //     return result;
    //  }

     async getPropertySettingDetailsPromises(objDatarop : object) :Promise<any>  {
      await new Promise<any>(resolve =>
      setTimeout(resolve, 5000))

      let headers= new Headers({'Content-Type' : 'application/json; charset=utf-8'});   
      let options=new RequestOptions({headers : headers});     

      return await this.http.post(this.servicePath.RoomDetails+'GetOptionSettings',
                        JSON.stringify(objDatarop),options).toPromise()
                        .catch(this.errorHandler);
      
    }

    //select room action
    addToRoomList(data : any) : Observable<any>
    {
      let headers = new Headers({'Content-Type' : 'application/json; charset=utf-8'});
      let options=new RequestOptions({headers :headers});

      return this.http.post(this.servicePath.SearchResult+'AddToRoomList',data,options)
                      .map((response:Response)=><any>response.json())
                      .catch(this.errorHandler);
    }

    //get selected rooms list
    getRoomList(data : any) : Observable<any>
    {
      let headers = new Headers({'Content-Type' : 'application/json; charset=utf-8'});
      let options=new RequestOptions({headers :headers});
      
      return this.http.post(this.servicePath.SearchResult+
                      'GetRoomListSummary?roomListId='+sessionStorage["RoomListId"],data,options)
                      .map((response:Response)=><any>response.json())
                      .catch(this.errorHandler);
    }
    
    removeSelectedRooms(data :any,roomId : any) : Observable<any> 
    {
        let headers = new Headers({'Content-Type' : 'application/json; charset=utf-8'});
        let options=new RequestOptions({headers :headers});

        roomId = roomId==undefined ? 0 : roomId;
        let apiQuerystr="RemoveRoomList?roomListId="+sessionStorage.RoomListId+"&roomId="+roomId;
    
        return this.http.post(this.servicePath.SearchResult+apiQuerystr,JSON.stringify(data),options)
                        .map((response:Response)=><any>response.json())
                        .catch(this.errorHandler);
    }

    //header details
    getHeaderDetails(body:any) : Observable<any> 
    {
      let headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8' });
      let options = new RequestOptions({ headers: headers});

      return this.http.post(this.servicePath.RoomDetails+'GetTemplateSettings',
                      JSON.stringify(body),options)
                      .map((response:Response)=><any>response.json())
                      .catch(this.errorHandler);
    }

        //Get available rooms
    GetNormalRuleList(body:any) : Observable<any> 
    {
      let headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8' });
      let options = new RequestOptions({ headers: headers});

      return this.http.post(this.servicePath.RoomDetails+'GetNormalRuleList',
                      JSON.stringify(body),options)
                      .map((response:Response)=><any>response.json())
                      .catch(this.errorHandler);
    }

    //Get available rooms
    GetReservationRuleList(body:any) : Observable<any> 
    {
      let headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8' });
      let options = new RequestOptions({ headers: headers});

      return this.http.post(this.servicePath.RoomDetails+'GetReservationRuleList',
                      JSON.stringify(body),options)
                      .map((response:Response)=><any>response.json())
                      .catch(this.errorHandler);
    }


    getDirectionInfo(body:any) : Observable<any> 
    {
      let headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8' });
      let options = new RequestOptions({ headers: headers});

      return this.http.post(this.servicePath.RoomDetails+'GetDirectionInfo',
                      JSON.stringify(body),options)
                      .map((response:Response)=><any>response.json())
                      .catch(this.errorHandler);
    }

    getPhotoGalleryImages(body:any) : Observable<any> 
    {
      let headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8' });
      let options = new RequestOptions({ headers: headers});
  
      return this.http.post(this.servicePath.RoomDetails+'GetPhotoGallary',
                      JSON.stringify(body),options)
                      .map((response:Response)=><any>response.json());
    }

    getRatesChanges(body:any) : Observable<any> 
    {
      let headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8' });
      let options = new RequestOptions({ headers: headers});
  
      return this.http.post(this.servicePath.CrsPropertySearch+'GetRoomRate',
                      JSON.stringify(body),options)
                      .map((response:Response)=><any>response.json());
    }

        //Get footer and property details
    getEditorContents(objDatarop : object) :Observable<object> 
    {
      let headers= new Headers({'Content-Type' : 'application/json; charset=utf-8'});   
      let options=new RequestOptions({
          headers : headers,
        });       
      return this.http.post(this.servicePath.RoomDetails+'GetContentMethod',
                      JSON.stringify(objDatarop),options)
                      .map((responce:Response) => <object>responce.json())
                      .catch(this.errorHandler);
    }
            //Get footer and property details
    getCMSeditorContents(objDatarop : object) :Observable<object> 
    {
      let headers= new Headers({'Content-Type' : 'application/json; charset=utf-8'});   
      let options=new RequestOptions({
          headers : headers,
        });       
      return this.http.post(this.servicePath.RoomDetails+'GetBookingSiteContent',
                      JSON.stringify(objDatarop),options)
                      .map((responce:Response) => <object>responce.json())
                      .catch(this.errorHandler);
    }

    errorHandler(error: HttpErrorResponse)  
    {
      return Observable.throw(error || "Server Error")    
    }
    LogErrorAngToText(body:any) : any
    {
      let headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8' });
      let options = new RequestOptions({ headers: headers});
  
      this.http.post(this.servicePath.RoomDetails+'LogErrorAngToText',
                        JSON.stringify(body),options).toPromise();                   
    }

}
