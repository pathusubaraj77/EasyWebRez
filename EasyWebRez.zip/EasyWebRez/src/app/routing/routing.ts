import { NgModule }                from '@angular/core';
import { RouterModule, Routes }    from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RegistrationComponent }   from './../checkout/component/registration/registration.component';
import { ThankYouBookingComponent} from './../thankyoubooking/component/thank-you-booking/thank-you-booking.component';
import { RoomDetailsComponent }    from  './../roomavailablity/component/room-details/room-details.component';
import { ResultComponent }         from  './../roomavailablity/component/result/result.component';
import { SearchWidgetComponent }   from './../roomavailablity/component/search-widget/search-widget.component'
import {NgbdDatepickerRange} from './../shared/component/datepicker-range/datepicker-range.component'


@NgModule({
  imports: [BrowserAnimationsModule,
  RouterModule.forRoot([
            {path: 'search-tab', component: SearchWidgetComponent, pathMatch: 'full'},
            {path: 'EasyWebrez/:id', component: RoomDetailsComponent, pathMatch: 'full'},
            {path: 'rd/:id', component: RoomDetailsComponent, pathMatch: 'full'},
            {path: '', component: RoomDetailsComponent, pathMatch: 'full'},
            {path: 'reg', component: RegistrationComponent},
            {path: 'tnk', component: ThankYouBookingComponent},
            {path :'EasyWebres/:id', component: RoomDetailsComponent},
            {path :'date', component: NgbdDatepickerRange},
            {path :'result', component: ResultComponent},], {enableTracing: false})
          ],
  exports: [ RouterModule ]
})
export class AppMainRoutingModule {}